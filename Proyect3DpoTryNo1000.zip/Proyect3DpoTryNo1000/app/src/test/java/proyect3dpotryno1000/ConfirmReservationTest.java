package proyect3dpotryno1000;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.text.SimpleDateFormat;
import proyect3dpotryno1000.modelo.Resort;
import proyect3dpotryno1000.modelo.Account;
import proyect3dpotryno1000.modelo.LoadInfoController;
import proyect3dpotryno1000.modelo.ReservationHandler;

public class ConfirmReservationTest {
    private Resort resort = new Resort();
    private String roomNumber = "1";
    private SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
    private LoadInfoController loadInfoController = new LoadInfoController(resort);
    private ReservationHandler reservationHandler = new ReservationHandler(loadInfoController);

    @BeforeEach

    @Test
    public void testConfirmReservationRoomAvailable() throws Exception {
        Account account = new Account();
        account.setState("available");
        account.setStartDate(null);
        account.setEndDate(null);
        account.setHaveToPay(0.0f);
        account.setOwner("-");
        resort.getAccounts().put(roomNumber, account);

        String result = reservationHandler.confirmReservation(roomNumber, formatter.parse("01-06-2023"), formatter.parse("10-06-2023"), "Owner");
        assertEquals("Room 1 is available! reservation was done", result);
    }

    @Test
    public void testConfirmReservationRoomTaken() throws Exception {
        Account account = new Account();
        account.setState("taken");
        account.setStartDate(formatter.parse("01-06-2023"));
        account.setEndDate(formatter.parse("10-06-2023"));
        account.setHaveToPay(0.0f);
        account.setOwner("owner");
        resort.getAccounts().put(roomNumber, account);

        String result = reservationHandler.confirmReservation(roomNumber, formatter.parse("01-06-2023"), formatter.parse("10-06-2023"), "Owner");
        assertEquals("Room 1 is currently taken.", result);
    }

    @Test
    public void testConfirmReservationUnknownState() throws Exception {
        Account account = new Account();
        account.setState("unknown");
        account.setStartDate(formatter.parse("01-06-2023"));
        account.setEndDate(formatter.parse("10-06-2023"));
        account.setHaveToPay(0.0f);
        account.setOwner("owner");
        resort.getAccounts().put(roomNumber, account);

        resort.getAccounts().put(roomNumber, account);

        String result = reservationHandler.confirmReservation(roomNumber, formatter.parse("01-06-2023"), formatter.parse("10-06-2023"), "Owner");
        assertEquals("Unknown state for room 1.", result);
    }

    @Test
public void testConfirmReservationNoRoomNumber() throws Exception {
    Account account = new Account();
    account.setState("available");
    account.setStartDate(null);
    account.setEndDate(null);
    account.setHaveToPay(0.0f);
    account.setOwner("-");
    resort.getAccounts().put(roomNumber, account);

    String result = reservationHandler.confirmReservation(null, formatter.parse("01-06-2023"), formatter.parse("10-06-2023"), "Owner");
    assertEquals("Rooms available for the given period: [1]", result);
}
@Test
public void testConfirmReservationInvalidParameters() throws Exception {
    String result = reservationHandler.confirmReservation(null, null, null, "Owner");
    assertEquals("Please provide a room number and/or a valid date range.", result);
}

}
