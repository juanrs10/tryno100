package proyect3dpotryno1000;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import proyect3dpotryno1000.modelo.Resort;
import proyect3dpotryno1000.modelo.StandardRoom;
import proyect3dpotryno1000.modelo.SuiteRoom;
import proyect3dpotryno1000.modelo.Habitacion;

public class LoadRoomsTest {

    private Resort resort;
    private String csvFile = "test.csv";

    @BeforeEach
    public void setup() {
        resort = new Resort();
        resort.csvFile = csvFile;
    }

    @AfterEach
    public void tearDown() throws IOException {
        Files.deleteIfExists(Paths.get(csvFile));
    }

    @Test
    public void testLoadRoomsNormal() throws IOException, ParseException {
        String content = "RoomNumber,Type,Kitchen,Balcony,View,Tower,Floor,Id,RoomSize,AirConditioning,Heating,BedSize,TV,CoffeeMachine,HypoallergenicBedding,Iron,HairDryer,ACVoltage,USBA,USBC,BreakfastIncluded\n" +
                "1,suite,true,true,true,Tower1,1,Room1,30,true,true,King,true,true,true,true,true,220,true,true,true";
        Files.write(Paths.get(csvFile), content.getBytes());

        resort.loadRooms();
        Map<String, Habitacion> rooms;
        rooms = resort.getRooms();
        assertEquals(1, rooms.size());
        SuiteRoom room = (SuiteRoom) rooms.get("1");
        assertEquals("suite", room.getTipo());
        assertEquals(true, room.isTieneCocina());
        // Add more asserts for the other fields...
    }

    @Test
    public void testLoadRoomsEmptyFile() throws IOException, ParseException {
        Files.createFile(Paths.get(csvFile));

        resort.loadRooms();

        assertTrue(resort.getRooms().isEmpty());
    }

    @Test
    public void testLoadRoomsNonExistentFile() throws IOException, ParseException {
        resort.csvFile = "C:/path/to/non_existent_file..csv";
        assertThrows(IOException.class, () -> resort.loadRooms());
    }
}
