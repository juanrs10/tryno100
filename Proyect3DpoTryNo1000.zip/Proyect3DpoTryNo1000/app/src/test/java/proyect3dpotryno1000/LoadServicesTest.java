package proyect3dpotryno1000;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import proyect3dpotryno1000.modelo.Resort;

public class LoadServicesTest {

    private Resort resort;
    private String csvFile = "test.csv";

    @BeforeEach
    public void setup() {
        resort = new Resort();
        resort.csvFile = csvFile;
    }

    @AfterEach
    public void tearDown() throws IOException {
        Files.deleteIfExists(Paths.get(csvFile));
    }

    @Test
    public void testLoadServicesNormal() throws IOException, ParseException {
        String content = "Service,Price\nSpa,50.0";
        Files.write(Paths.get(csvFile), content.getBytes());

        resort.loadServices();
        Map<String, Float> services = resort.getServices();
        assertEquals(1, services.size());
        assertEquals(50.0, services.get("Spa"),0.0001);
    }

    @Test
    public void testLoadServicesEmptyFile() throws IOException, ParseException {
        Files.createFile(Paths.get(csvFile));

        resort.loadServices();

        assertTrue(resort.getServices().isEmpty());
    }

    @Test
    public void testLoadServicesNonExistentFile() throws IOException, ParseException {
        resort.csvFile = "C:/path/to/non_existent_file..csv";
        assertThrows(IOException.class, () -> resort.loadServices());
    }
}
