package proyect3dpotryno1000;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import proyect3dpotryno1000.modelo.Resort;
import proyect3dpotryno1000.modelo.Sale;
import proyect3dpotryno1000.modelo.Account;

public class LoadAuthUsersTest {

    private Resort resort;
    private String csvFile = "test.csv";

    @BeforeEach
    public void setup() {
        resort = new Resort();
        resort.csvFile = csvFile;
    }

    @AfterEach
    public void tearDown() throws IOException {
        Files.deleteIfExists(Paths.get(csvFile));
    }

    @Test
    public void testloadAuthUsersNormal() throws IOException, ParseException {
        String content = "user,password\nmanager,manager";
        Files.write(Paths.get(csvFile), content.getBytes());

        resort.loadAuthUsers();
        HashMap<String,String> authUsers;
        authUsers = resort.getAuthUsers();
        assertEquals(1, authUsers.size());
        String pass = authUsers.get("manager");
        assertEquals("manager", pass);
    }

    @Test
    public void testloadAuthUsersEmptyFile() throws IOException, ParseException {
        Files.createFile(Paths.get(csvFile));

        resort.loadAuthUsers();

        assertTrue(resort.getAccounts().isEmpty());
    }

    @Test
    public void testloadAuthUsersNonExistentFile() throws IOException, ParseException {
        
    resort.csvFile = "C:/path/to/non_existent_file..csv";
    assertThrows(IOException.class, () -> resort.loadAuthUsers());
}

}

