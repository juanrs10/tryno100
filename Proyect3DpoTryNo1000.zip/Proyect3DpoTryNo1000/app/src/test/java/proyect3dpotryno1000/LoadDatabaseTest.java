package proyect3dpotryno1000;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import proyect3dpotryno1000.modelo.Resort;
import proyect3dpotryno1000.modelo.Account;

public class LoadDatabaseTest {

    private Resort resort;
    private String csvFile = "test.csv";

    @BeforeEach
    public void setup() {
        resort = new Resort();
        resort.csvFile = csvFile;
    }

    @AfterEach
    public void tearDown() throws IOException {
        Files.deleteIfExists(Paths.get(csvFile));
    }

    @Test
    public void testLoadDatabaseNormal() throws IOException, ParseException {
        String content = "RoomNumber,State,StartDate,EndDate,HaveToPay,Owner\n1,Available,2023-06-01,2023-06-30,0,-";
        Files.write(Paths.get(csvFile), content.getBytes());

        resort.loadDatabase();
        Map<String, Account> accounts;
        accounts = resort.getAccounts();
        assertEquals(1, accounts.size());
        Account account = accounts.get("1");
        assertEquals("Available", account.getState());
    }

    @Test
    public void testLoadDatabaseEmptyFile() throws IOException, ParseException {
        Files.createFile(Paths.get(csvFile));

        resort.loadDatabase();

        assertTrue(resort.getAccounts().isEmpty());
    }

    @Test
    public void testLoadDatabaseNonExistentFile() throws IOException, ParseException {
        
    resort.csvFile = "C:/path/to/non_existent_file..csv";
    assertThrows(IOException.class, () -> resort.loadDatabase());
}

}

