package proyect3dpotryno1000;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import proyect3dpotryno1000.modelo.Resort;
import proyect3dpotryno1000.modelo.Sale;
import proyect3dpotryno1000.modelo.Account;

public class LoadSalesTest {

    private Resort resort;
    private String csvFile = "test.csv";

    @BeforeEach
    public void setup() {
        resort = new Resort();
        resort.csvFile = csvFile;
    }

    @AfterEach
    public void tearDown() throws IOException {
        Files.deleteIfExists(Paths.get(csvFile));
    }

    @Test
    public void testloadSalesNormal() throws IOException, ParseException {
        String content = "Date,Items,Price\n2023-05-23,Caesar Salad,43.50";
        Files.write(Paths.get(csvFile), content.getBytes());

        resort.loadSales();
        ArrayList<Sale> sales;
        sales = resort.getSales();
        assertEquals(1, sales.size());
        Sale sale = sales.get(0);
        assertEquals(43.50f, sale.getPrice());
    }

    @Test
    public void testloadSalesEmptyFile() throws IOException, ParseException {
        Files.createFile(Paths.get(csvFile));

        resort.loadSales();

        assertTrue(resort.getAccounts().isEmpty());
    }

    @Test
    public void testloadSalesNonExistentFile() throws IOException, ParseException {
        
    resort.csvFile = "C:/path/to/non_existent_file..csv";
    assertThrows(IOException.class, () -> resort.loadSales());
}

}

