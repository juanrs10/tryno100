package proyect3dpotryno1000;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import proyect3dpotryno1000.modelo.Resort;

public class LoadMenuTest {

    private Resort resort;
    private String csvFile = "test.csv";

    @BeforeEach
    public void setup() {
        resort = new Resort();
        resort.csvFile = csvFile;
    }

    @AfterEach
    public void tearDown() throws IOException {
        Files.deleteIfExists(Paths.get(csvFile));
    }

    @Test
    public void testLoadMenuNormal() throws IOException, ParseException {
        String content = "Item,Price\nPizza,8.5";
        Files.write(Paths.get(csvFile), content.getBytes());

        resort.loadMenu();
        Map<String, Float> menu;
        menu = resort.getMenu();
        assertEquals(1, menu.size());
        assertEquals(8.5f, menu.get("Pizza"));
    }

    @Test
    public void testLoadMenuEmptyFile() throws IOException, ParseException {
        Files.createFile(Paths.get(csvFile));

        resort.loadMenu();

        assertTrue(resort.getMenu().isEmpty());
    }

    @Test
    public void testLoadMenuNonExistentFile() throws IOException, ParseException {
        resort.csvFile = "C:/path/to/non_existent_file..csv";
        assertThrows(IOException.class, () -> resort.loadMenu());
    }
}
