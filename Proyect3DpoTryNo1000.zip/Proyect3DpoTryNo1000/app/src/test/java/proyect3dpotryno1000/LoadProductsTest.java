package proyect3dpotryno1000;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import proyect3dpotryno1000.modelo.Resort;

public class LoadProductsTest {

    private Resort resort;
    private String csvFile = "test.csv";

    @BeforeEach
    public void setup() {
        resort = new Resort();
        resort.csvFile = csvFile;
    }

    @AfterEach
    public void tearDown() throws IOException {
        Files.deleteIfExists(Paths.get(csvFile));
    }

    @Test
    public void testLoadProductsNormal() throws IOException, ParseException {
        String content = "Product,Price\nCoke,1.5";
        Files.write(Paths.get(csvFile), content.getBytes());

        resort.loadProducts();
        Map<String, Float> products;
        products = resort.getProducts();
        assertEquals(1, products.size());
        assertEquals(1.5f, products.get("Coke"));
    }

    @Test
    public void testLoadProductsEmptyFile() throws IOException, ParseException {
        Files.createFile(Paths.get(csvFile));

        resort.loadProducts();

        assertTrue(resort.getProducts().isEmpty());
    }

    @Test
    public void testLoadProductsNonExistentFile() throws IOException, ParseException {
        resort.csvFile = "C:/path/to/non_existent_file..csv";
        assertThrows(IOException.class, () -> resort.loadProducts());
    }
}
