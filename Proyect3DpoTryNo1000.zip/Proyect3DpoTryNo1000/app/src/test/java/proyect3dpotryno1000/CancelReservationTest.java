package proyect3dpotryno1000;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import proyect3dpotryno1000.modelo.Resort;
import proyect3dpotryno1000.modelo.Sale;
import proyect3dpotryno1000.modelo.Account;
import proyect3dpotryno1000.modelo.LoadInfoController;
import proyect3dpotryno1000.modelo.ReservationHandler;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class CancelReservationTest {

    private Resort resort = new Resort();
    private LoadInfoController loadInfoController = new LoadInfoController(resort);
    private Account account = new Account();
    private ReservationHandler reservationHandler = new ReservationHandler(loadInfoController);


    @BeforeEach
    public void setup() {
        account = new Account();
        account.setState("available");
        account.setStartDate(null);
        account.setEndDate(null);
        account.setHaveToPay(0.0f);
        account.setOwner("-");
        loadInfoController.setAccount(account,"1200");
        reservationHandler = new ReservationHandler(loadInfoController);
    }

@Test
public void testCancelReservation() {
    // Create a new reservation more than 48 hours from now
    Date startDate = new Date(new Date().getTime() + TimeUnit.MILLISECONDS.convert(72, TimeUnit.HOURS));
    Date endDate = new Date(new Date().getTime() + TimeUnit.MILLISECONDS.convert(96, TimeUnit.HOURS));
    reservationHandler.confirmReservation("1200", startDate, endDate, "Owner");

    String result = reservationHandler.cancelReservation("1200");
    assertEquals("Reservation cancelled successfully!", result);
}
@Test
public void testCancelReservationLessThan48Hours() {
    // Create a new reservation less than 48 hours from now
    Date startDate = new Date(new Date().getTime() + TimeUnit.MILLISECONDS.convert(24, TimeUnit.HOURS));
    Date endDate = new Date(new Date().getTime() + TimeUnit.MILLISECONDS.convert(48, TimeUnit.HOURS));
    String confirmResult = reservationHandler.confirmReservation("1200", startDate, endDate, "Owner");

    // Assert that the reservation was successful
    assertEquals("Room 1200 is available! reservation was done", confirmResult);

    String cancelResult = reservationHandler.cancelReservation("1200");
    assertEquals("You can only cancel 2 days before the reservation takes place.", cancelResult);
}

@Test
public void testCancelReservationRoomAvailable() {
    String result = reservationHandler.cancelReservation("1200");
    assertEquals("The room is already available, no reservation to cancel.", result);
}

@Test
public void testCancelReservationNonExistentRoom() {
    String result = reservationHandler.cancelReservation("9999"); // Assuming that room 999 does not exist
    assertEquals("There is no reservation for that room.", result);
}

    
}
