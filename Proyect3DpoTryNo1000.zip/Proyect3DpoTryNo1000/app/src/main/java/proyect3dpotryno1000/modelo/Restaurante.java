package proyect3dpotryno1000.modelo;

import java.util.HashMap;
import java.util.ArrayList;

public class Restaurante {

    HashMap<String,Float> menu;
    ArrayList<Sale> sales;
    LoadInfoController loadInfoController;

    public Restaurante(LoadInfoController loadInfoController){

        this.loadInfoController = loadInfoController;

        sales = loadInfoController.getSales();
        menu = loadInfoController.getMenu();


    }

    public float getTotalSales() {
        float total = 0f;
        //Iterate over all the sales array, use method .getPrice
        for(Sale sale : sales) {
            total += sale.getPrice();
        }
        return total;
    }

    public float getAverageSales(){

        return getTotalSales()/sales.size();
    }



}
