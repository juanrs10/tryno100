package proyect3dpotryno1000.modelo;

import java.util.HashMap;

public class LoginController
{   
    private static HashMap<String,String> authUsers;
    private LoadInfoController loadInfoController;

    public LoginController(LoadInfoController loadInfoController){

        this.loadInfoController = loadInfoController;

        this.authUsers = loadInfoController.getAuthUsers();

    }

    public String authenticate(String username, String password)
    {
        String storedPassword = authUsers.get(username);

        if (storedPassword != null && storedPassword.equals(password)) {

            if (username.equals("manager") | username.equals("receptionist") | username.equals("client") | username.equals("employee")){

                return username;
            }

            else {

                return "client";
            }
            
        } else {
            return "";
        }
    }

    public String register(String username, String password) {
        // Check if the username already exists
        if (authUsers.containsKey(username)) {
            return "There is already an account with that name";
        }
    
        // If the username does not exist, add the new user
        loadInfoController.setAuthUsers(username, password);
    
        return "New user created!";
    }
    
}

