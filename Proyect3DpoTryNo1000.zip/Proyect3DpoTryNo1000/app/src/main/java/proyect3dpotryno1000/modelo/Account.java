package proyect3dpotryno1000.modelo;
import java.io.ObjectInputFilter.Status;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Account {

    private String roomNumber,state,owner;
    private Date startDate,endDate;
    private Float haveToPay;
    private HashMap<String,Float> serviceProductsUsed = new HashMap<>();
    private Float trash;


    public void Account(){


    }

    public void setRoomNumber(String roomNumber){


        this.roomNumber = roomNumber;
    }

    public void setState(String state){


        this.state = state;
    }

    public void setStartDate(Date startDate){


        this.startDate = startDate;
    }

    public void setEndDate(Date endDate){


        this.endDate = endDate;
    }

    public void setHaveToPay(Float haveToPay){


        this.haveToPay = haveToPay;
    }

    public void setOwner(String owner){

        this.owner = owner;

    }

    public String getRoomNumber(){

        return roomNumber;

    }

    public String getState(){

        return state;

    }

    public Date getStartDate(){

        return startDate;

    }

    public Date getEndDate(){

        return endDate;
    }

    public Float getHaveToPay(){

        return haveToPay;

    }

    public String getOwner(){

        return owner;

    }

    public void charge(String serviceProduct, Float price){

        serviceProductsUsed.put(serviceProduct, price);

        trash = calculateHaveToPay();

    }

    public float calculateHaveToPay() {
        float total = 0.0f;
        for (float price : serviceProductsUsed.values()) {
            total += price;
        }

        haveToPay = total;
        return total;
    }

    public String generateBill() {
        StringBuilder bill = new StringBuilder();
        bill.append("Room Number: ").append(roomNumber).append("\n");
        bill.append("Owner: ").append(owner).append("\n");
        bill.append("Start Date: ").append(startDate).append("\n");
        bill.append("End Date: ").append(endDate).append("\n");
        bill.append("\n===== Services and Products Used =====\n");
        
        for (Map.Entry<String, Float> entry : serviceProductsUsed.entrySet()) {
            bill.append(entry.getKey()).append(": $").append(entry.getValue()).append("\n");
        }

        bill.append("\n===== Total to Pay =====\n");
        bill.append("$").append(haveToPay);

        return bill.toString();
    }

    public String confirmCharge(Float roomNumber, String serviceProductName){

        return "";


    }



    
}
