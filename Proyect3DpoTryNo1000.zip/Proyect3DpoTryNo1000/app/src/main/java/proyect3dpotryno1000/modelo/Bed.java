package proyect3dpotryno1000.modelo;

public class Bed {
    private static final String SOFA_BED = "sofa bed";
    private static final String CHILD = "child";
    private static final String SINGLE = "single";
    private static final String DOUBLE = "double";
    private String type;
    private int adultCapacity;
    private int childCapacity;
    
    public Bed() {
        
    }
    
    public Bed(String type) {
        this.type = type;
        
        if (this.type.equals(DOUBLE)) {
            adultCapacity = 2;
            childCapacity = 3;
        } else if (this.type.equals(SINGLE)) {
            adultCapacity = 1;
            childCapacity = 2;
        } else if (this.type.equals(CHILD)) {
            adultCapacity = 0;
            childCapacity = 1;
        } else if (this.type.equals(SOFA_BED)) {
            adultCapacity = 1;
            childCapacity = 1;
        }    
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getAdultCapacity() {
        return adultCapacity;
    }

    public void setAdultCapacity(int adultCapacity) {
        this.adultCapacity = adultCapacity;
    }

    public int getChildCapacity() {
        return childCapacity;
    }

    public void setChildCapacity(int childCapacity) {
        this.childCapacity = childCapacity;
    }
    
    public static String getSofaBed() {
        return SOFA_BED;
    }

    public static String getChild() {
        return CHILD;
    }

    public static String getSingle() {
        return SINGLE;
    }

    public static String getDouble() {
        return DOUBLE;
    }

    @Override
    public String toString() {
        return type + ", " + adultCapacity + " adults" + ", " + childCapacity + " children";
    }

}
