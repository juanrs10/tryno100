package proyect3dpotryno1000.modelo;
import java.io.IOException;
//IF POSSIBLE IMPLEMENT THE CHECK IF THE RESTAURANT ITEM CAN BE CONSUMED IN THE ROOM OR HAVE TO GO TO RESTAURANT
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.ArrayList;


public class LoadInfoController {

    private static Resort resort;
    private static HashMap<String,Account> accounts;
    private static HashMap<String,Float> products;
    private static HashMap<String,Float> services;
    private static HashMap<String,Float> menu;
    private static HashMap<String,String> authUsers;
    private static HashMap<String,Float> serviceProductMap = new HashMap<>();
    private static HashMap<String,Habitacion> rooms;




    public LoadInfoController(Resort resort){

        this.resort = resort;


    }

    public void loadInfo() throws IOException, ParseException{

        resort.loadProducts();
        resort.loadRooms();
        resort.loadServices();
        resort.loadDatabase();
        resort.loadMenu();
        resort.loadAuthUsers();
        this.accounts = resort.getAccounts();
        this.products = resort.getProducts();
        this.services = resort.getServices();
        this.authUsers = resort.getAuthUsers();
        this.rooms = resort.getRooms();
        this.menu = resort.getMenu();

    }

    public HashMap<String, Float> getServices(){

        return resort.getServices();


    }

    public HashMap<String, Float> getProducts(){

        return resort.getProducts();


    }

    public HashMap<String, Habitacion> getRooms(){

        return resort.getRooms();


    }

    public HashMap<String, Float> getMenu(){

        return resort.getMenu();


    }

    public HashMap<String, String> getAuthUsers(){

        return resort.getAuthUsers();
    }


    public HashMap<String, Account> getAccounts(){

        return resort.getAccounts();
    }

    public boolean setServices(String service, Float price){

        return resort.setServices(service, price);

    }

    public boolean setProducts(String product, Float price){

        return resort.setProducts(product, price);
        


    }

    public boolean setRooms(Habitacion room, String number){

        return resort.setRoom(room, number);



    }

    public boolean setAccount(Account account, String roomNumber){

        return resort.setAccount(account, roomNumber);
    }

    public void setAuthUsers(String user, String password){

        resort.setAuthUsers(user, password);
    }

    public HashMap<String,Float> getServiceProductMap(){

        // Merge services and products
        serviceProductMap.putAll(services);
        serviceProductMap.putAll(products);
        serviceProductMap.putAll(menu);
        return serviceProductMap;
    }

    public String confirmCharge(String roomNumber, String serviceProductName){
        // Get the accounts map from the resort
    
        try {
            // Search the account in the accounts map with the roomNumber key
            Account account = accounts.get(roomNumber);
            
            if(account == null){
                return "No account found for the provided room number. Please check the inputs.";
            }
    
            // Get the price of the service or product
            Float price = null;
            if (products.containsKey(serviceProductName)) {
                price = products.get(serviceProductName);
            } else if (services.containsKey(serviceProductName)) {
                price = services.get(serviceProductName);
            }
    
            if (price == null) {
                return "No service or product found with the provided name. Please check the inputs.";
            }
    
            // Add the charge to the account
            account.charge(serviceProductName, price);
            return "Charge done successfully.";
    
        } catch (Exception e) {
            // TODO: handle exception
            return "An error occurred: " + e.getMessage();
        }   
    }

    public String searchRoom(String roomNumber) {
        // Assuming rooms is your HashMap where key is room number and value is the Habitacion object
        Habitacion habitacion = rooms.get(roomNumber);
        StringBuilder roomSummary = new StringBuilder();
        
        if (habitacion != null) {
            roomSummary.append("Room Summary:\n");
            roomSummary.append("Type: ").append(habitacion.getTipo()).append("\n");
            roomSummary.append("Has Kitchen: ").append(habitacion.isTieneCocina()).append("\n");
            roomSummary.append("Has Balcony: ").append(habitacion.isTieneBalcon()).append("\n");
            roomSummary.append("Has View: ").append(habitacion.isTieneVista()).append("\n");
            roomSummary.append("Tower: ").append(habitacion.getTorre()).append("\n");
            roomSummary.append("Floor: ").append(habitacion.getPiso()).append("\n");
            roomSummary.append("Room Number: ").append(habitacion.getId()).append("\n");
            roomSummary.append("Size in Square Meters: ").append(habitacion.getTamanoHab()).append("\n");
            roomSummary.append("Has Air Conditioning: ").append(habitacion.isTieneAC()).append("\n");
            roomSummary.append("Has Heating: ").append(habitacion.isTieneCalefaccion()).append("\n");
            roomSummary.append("Bed Size: ").append(habitacion.getTamanoCama()).append("\n");
            roomSummary.append("Has TV: ").append(habitacion.isTieneTV()).append("\n");
            roomSummary.append("Has Coffee Maker: ").append(habitacion.isTieneCafetera()).append("\n");
            roomSummary.append("Has Hypoallergenic Bedding and Rugs: ").append(habitacion.isTieneRopCama_TapHipoaler()).append("\n");
            roomSummary.append("Has Iron: ").append(habitacion.isTienePlancha()).append("\n");
            roomSummary.append("Has Hair Dryer: ").append(habitacion.isTieneSecadorPelo()).append("\n");
            roomSummary.append("AC Voltage: ").append(habitacion.getVoltajeAC()).append("\n");
            roomSummary.append("Has USB-A Ports: ").append(habitacion.isTieneTomaUSBA()).append("\n");
            roomSummary.append("Has USB-C Ports: ").append(habitacion.isTieneTomaUSBC()).append("\n");
            roomSummary.append("Includes Breakfast: ").append(habitacion.isIncluyeDesayuno()).append("\n").append("\n");

        } else {
            roomSummary.append("Room with number ").append(roomNumber).append(" not found.");
        }
        
        return roomSummary.toString();
    }

    public String chargeBill(String roomNumber){

        Account account = accounts.get(roomNumber);
        return account.generateBill();
    }

    public String getRoomsSummary(String roomNumber){
        StringBuilder summary = new StringBuilder();
        Account account = accounts.get(roomNumber);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    
        Habitacion room = rooms.get(roomNumber);
            summary.append("Room number: ").append(roomNumber).append("\n")
                .append("Type: ").append(room.getTipo()).append("\n")
                .append("Tower: ").append(room.getTorre()).append("\n")
                .append("Floor: ").append(room.getPiso()).append("\n")
                .append("ID: ").append(room.getId()).append("\n")
                .append("Capacity - Adults: ").append(room.getCapacidadAdultos()).append(", Children: ").append(room.getCapacidadNinios()).append("\n")
                .append("Room size: ").append(room.getTamanoHab()).append("\n")
                .append("Has kitchen: ").append(room.isTieneCocina() ? "Yes" : "No").append("\n")
                .append("Has balcony: ").append(room.isTieneBalcon() ? "Yes" : "No").append("\n")
                .append("Has view: ").append(room.isTieneVista() ? "Yes" : "No").append("\n")
                .append("Has AC: ").append(room.isTieneAC() ? "Yes" : "No").append("\n")
                .append("Has heating: ").append(room.isTieneCalefaccion() ? "Yes" : "No").append("\n")
                .append("Bed size: ").append(room.getTamanoCama()).append("\n")
                .append("Has TV: ").append(room.isTieneTV() ? "Yes" : "No").append("\n")
                .append("Has coffee maker: ").append(room.isTieneCafetera() ? "Yes" : "No").append("\n")
                .append("Has hypoallergenic bedding: ").append(room.isTieneRopCama_TapHipoaler() ? "Yes" : "No").append("\n")
                .append("Has iron: ").append(room.isTienePlancha() ? "Yes" : "No").append("\n")
                .append("Has hair dryer: ").append(room.isTieneSecadorPelo() ? "Yes" : "No").append("\n")
                .append("AC voltage: ").append(room.getVoltajeAC()).append("\n")
                .append("Breakfast included: ").append(room.getIncluyeDesayuno() ? "Yes" : "No").append("\n")
                .append("\n")
                .append("Account Details").append("\n")
                .append("Status: ").append(account.getState()).append("\n")
                .append("startDate: ").append("startDate: ").append(format.format(account.getStartDate())).append("\n")
                .append("endDate: ").append("endDate: ").append(format.format(account.getEndDate())).append("\n")               .append("Have to pay: ").append(account.getHaveToPay().toString()).append("\n")
                .append("Owner: ").append(account.getOwner()).append("\n");
    
        return summary.toString();
    }

    public String getServicesSummary(String serviceName){

        Float price = services.get(serviceName);
        StringBuilder summary = new StringBuilder();

        summary.append("Service: ").append(serviceName).append("\n")
        .append("Pice: ").append(price.toString()).append("\n");
        
        return summary.toString();


    }

    public String getProductsSummary(String productName){

        Float price = products.get(productName);
        StringBuilder summary = new StringBuilder();

        summary.append("Service: ").append(productName).append("\n")
        .append("Pice: ").append(price.toString()).append("\n");
        
        return summary.toString();


    }

    public String getMenuSummary(String item){

        Float price = menu.get(item);
        StringBuilder summary = new StringBuilder();

        summary.append("Service: ").append(item).append("\n")
        .append("Pice: ").append(price.toString()).append("\n");
        
        return summary.toString();


    }

    public ArrayList<Sale> getSales(){

        return resort.getSales();
    }
    public String editRoom(String roomNumber, String type, String tower, String floor, String id, String capacity, String roomSize, Boolean hasKitchen, Boolean hasBalcony, Boolean hasView, Boolean hasAC, Boolean hasHeating, String bedSize, Boolean hasTV, Boolean hasCofeeMaker, Boolean hasHypoallergenicBedding, Boolean hasIron, Boolean hasHairDryer, String ACVoltage, Boolean hasBreakfastIncluded){

        Habitacion room = rooms.get(roomNumber);
    
        if(room == null) {
            // Handle the case when there is no room with the given room number
            return "No room found with the given room number.";
        }
      
        try {
            room.setTipo(type);
            room.setTorre(tower);
            room.setPiso(Integer.parseInt(floor));
            room.setId(id);
            room.setCapacidadAdultos(Integer.parseInt(capacity));
            room.setTamanoHab(Integer.parseInt(roomSize));
            room.setTieneCocina(hasKitchen);
            room.setTieneBalcon(hasBalcony);
            room.setTieneVista(hasView);
            room.setTieneAC(hasAC);
            room.setTieneCalefaccion(hasHeating);
            room.setTamanoCama(bedSize);
            room.setTieneTV(hasTV);
            room.setTieneCafetera(hasCofeeMaker);
            room.setTieneRopCama_TapHipoaler(hasHypoallergenicBedding);
            room.setTienePlancha(hasIron);
            room.setTieneSecadorPelo(hasHairDryer);
            room.setVoltajeAC(Integer.parseInt(ACVoltage));
            room.setIncluyeDesayuno(hasBreakfastIncluded);
            return "Edit completed";
        } catch (NumberFormatException e) {
            // Handle the case when a string cannot be parsed to an integer
            return "Invalid input";
        } 
    }

    public String editService(String service, String serviceReplace, Float price) {
        // Check if the original service exists and the replacement does not
        if (services.containsKey(service) && !services.containsKey(serviceReplace)) {
            // Replace the service
            Float oldPrice = services.remove(service);
            services.put(serviceReplace, price);
    
            // Optionally, you could also check if the price actually changed
            if (!oldPrice.equals(price)) {
                return "Service " + service + " was changed to " + serviceReplace + " with new price " + price;
            } else {
                return "Service " + service + " was changed to " + serviceReplace + ", price remained the same.";
            }
        } else if (services.containsKey(serviceReplace)) {
            // The replacement service already exists
            return "Service " + serviceReplace + " already exists. No changes were made.";
        } else {
            // The original service does not exist
            return "Service " + service + " does not exist. No changes were made.";
        }
    }

    public String editProduct(String service, String serviceReplace, Float price) {
        // Check if the original service exists and the replacement does not
        if (products.containsKey(service) && !products.containsKey(serviceReplace)) {
            // Replace the service
            Float oldPrice = products.remove(service);
            products.put(serviceReplace, price);
    
            // Optionally, you could also check if the price actually changed
            if (!oldPrice.equals(price)) {
                return "Product " + service + " was changed to " + serviceReplace + " with new price " + price;
            } else {
                return "Product " + service + " was changed to " + serviceReplace + ", price remained the same.";
            }
        } else if (products.containsKey(serviceReplace)) {
            // The replacement service already exists
            return "Product " + serviceReplace + " already exists. No changes were made.";
        } else {
            // The original service does not exist
            return "Product " + service + " does not exist. No changes were made.";
        }
    }

    public String editMenu(String service, String serviceReplace, Float price) {
        // Check if the original service exists and the replacement does not
        if (menu.containsKey(service) && !menu.containsKey(serviceReplace)) {
            // Replace the service
            Float oldPrice = menu.remove(service);
            menu.put(serviceReplace, price);
    
            // Optionally, you could also check if the price actually changed
            if (!oldPrice.equals(price)) {
                return "Item " + service + " was changed to " + serviceReplace + " with new price " + price;
            } else {
                return "Item " + service + " was changed to " + serviceReplace + ", price remained the same.";
            }
        } else if (menu.containsKey(serviceReplace)) {
            // The replacement service already exists
            return "Item " + serviceReplace + " already exists. No changes were made.";
        } else {
            // The original service does not exist
            return "Item " + service + " does not exist. No changes were made.";
        }
    }

    public String createRoom(String roomNumber, String type, String tower, String floor, String id, String capacity, String roomSize, Boolean hasKitchen, Boolean hasBalcony, Boolean hasView, Boolean hasAC, Boolean hasHeating, String bedSize, Boolean hasTV, Boolean hasCofeeMaker, Boolean hasHypoallergenicBedding, Boolean hasIron, Boolean hasHairDryer, String ACVoltage, Boolean hasBreakfastIncluded){

        Habitacion room;
    
        try {
            // Parse numeric values first to avoid creating room in case of invalid input
            int piso = Integer.parseInt(floor);
            int capacidadAdultos = Integer.parseInt(capacity);
            int tamanoHab = Integer.parseInt(roomSize);
            int voltajeAC = Integer.parseInt(ACVoltage);
    
            // Constants for USB ports, adjust these as necessary
            boolean tomaUSBA = true;
            boolean tomaUSBC = true;
    
            // Create the room object based on the room type
            switch (type) {
                case "standard":
                    room = new StandardRoom(type, hasKitchen, hasBalcony, hasView, tower, piso, id, tamanoHab, hasAC, hasHeating, bedSize, hasTV, hasCofeeMaker, hasHypoallergenicBedding, hasIron, hasHairDryer, voltajeAC, tomaUSBA, tomaUSBC, hasBreakfastIncluded);
                    break;
                case "suite":
                    // Adjust these parameters according to the HabitacionSuite constructor
                    room = new SuiteRoom(type, hasKitchen, hasBalcony, hasView, tower, piso, id, tamanoHab, hasAC, hasHeating, bedSize, hasTV, hasCofeeMaker, hasHypoallergenicBedding, hasIron, hasHairDryer, voltajeAC, tomaUSBA, tomaUSBC, hasBreakfastIncluded);
                    break;
                case "double suite":
                    // Adjust these parameters according to the HabitacionSuiteDoble constructor
                    room = new SuiteDoubleRoom(type, hasKitchen, hasBalcony, hasView, tower, piso, id, tamanoHab, hasAC, hasHeating, bedSize, hasTV, hasCofeeMaker, hasHypoallergenicBedding, hasIron, hasHairDryer, voltajeAC, tomaUSBA, tomaUSBC, hasBreakfastIncluded);
                    break;
                default:
                    return "Invalid room type";
            }
    
            // Add the room to the rooms HashMap
            rooms.put(roomNumber, room);
    
            return "Room creation completed";
        } catch (NumberFormatException e) {
            // Handle the case when a string cannot be parsed to an integer
            return "Invalid input";
        } 
    }

    public String createService(String name, Float price){

        // add the new key and value to the services hashmap
        services.put(name, price);
    
        return "Service creation completed";
    }

    public String createProduct(String name, Float price){

        // add the new key and value to the services hashmap
        products.put(name, price);
    
        return "Product creation completed";
    }

    public String createMenu(String name, Float price){

        // add the new key and value to the services hashmap
        menu.put(name, price);
    
        return "Menu item creation completed";
    }

    public HashMap<String, Float> calculateOccupancy() {
        // Initialize a HashMap to store the number of occupied rooms for each day
        HashMap<LocalDate, Integer> occupiedRoomsPerDay = new HashMap<>();
    
        // For each account in the accounts map
        for (Account account : accounts.values()) {
            // Get the start and end dates of the reservation
            Date startDate = account.getStartDate();
            Date endDate = account.getEndDate();
            
            // Check if startDate and endDate are not null
            if (startDate != null && endDate != null) {
                LocalDate startLocalDate = startDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                LocalDate endLocalDate = endDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    
                // For each day between the start and end dates
                for (LocalDate date = startLocalDate; !date.isAfter(endLocalDate); date = date.plusDays(1)) {
                    // Increment the count of occupied rooms for that day
                    occupiedRoomsPerDay.put(date, occupiedRoomsPerDay.getOrDefault(date, 0) + 1);
                }
            }
        }
    
        // Get the total number of rooms
        int totalRooms = rooms.keySet().size(); // Assumes this function is available, returns the total number of rooms
    
        // Initialize the return HashMap
        HashMap<String, Float> occupancyRatePerDay = new HashMap<>();
    
        // For each day in the occupiedRoomsPerDay map
        for (Map.Entry<LocalDate, Integer> entry : occupiedRoomsPerDay.entrySet()) {
            // Calculate the occupancy rate for this day
            float occupancyRate = (entry.getValue() * 100.0f) / totalRooms;
    
            // Add the occupancy rate to the occupancyRatePerDay map
            occupancyRatePerDay.put(entry.getKey().toString(), occupancyRate);
        }
    
        // Return the occupancy rate per day map
        return occupancyRatePerDay;
    }
    
    
}
