package proyect3dpotryno1000.modelo;
import proyect3dpotryno1000.modelo.Habitacion;//HabitacionEstandar
import proyect3dpotryno1000.modelo.Account;//HabitacionEstandar
import proyect3dpotryno1000.modelo.StandardRoom;//HabitacionEstandar
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;


import java.util.ArrayList;
import java.util.List;


import java.io.*;
import java.util.*;

public class Resort {
    public final boolean FREE_PARKING = true;
    public final boolean PAID_PARKING = true;
    public final boolean POOL = true;
    public final boolean ZONAS_HUMEDAS = true;
    public final boolean BBQ = true;
    public final boolean OPEN24H = true;
    public final boolean PET_FRIENDLY = true;

    public HashMap<String, Float> services = new HashMap<>();
    public HashMap<String, Float> menu = new HashMap<>();
    public HashMap<String, Habitacion> rooms = new HashMap<>();
    public HashMap<String, Float> products = new HashMap<>();
    public HashMap<String, Account> accounts = new HashMap<>();
    public HashMap<String, String> authUsers = new HashMap<>();
    public ArrayList<Sale> sales = new ArrayList<>();

    public String csvFile;

    public void loadProducts()throws IOException, ParseException{
        csvFile = "C:/Users/PC/Documents/Proyect3DpoTryNo1000/app/src/main/java/proyect3dpotryno1000/Info/Products.csv";
        String line = "";
        String cvsSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // skip the header of the csv
            br.readLine();
            while ((line = br.readLine()) != null) {
                // use comma as separator
                String[] product = line.split(cvsSplitBy);
                products.put(product[0], Float.parseFloat(product[1]));
            }

        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }

        System.out.println(products);
    }


    public void loadServices()throws IOException, ParseException{
        csvFile = "C:/Users/PC/Documents/Proyect3DpoTryNo1000/app/src/main/java/proyect3dpotryno1000/Info/Services.csv";
        String line = "";
        String cvsSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // skip the header of the csv
            br.readLine();
            while ((line = br.readLine()) != null) {
                // use comma as separator
                String[] product = line.split(cvsSplitBy);
                services.put(product[0], Float.parseFloat(product[1]));
            }

        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
    }

    public void loadMenu()throws IOException, ParseException{
        csvFile = "C:/Users/PC/Documents/Proyect3DpoTryNo1000/app/src/main/java/proyect3dpotryno1000/Info/Menu.csv";
        String line = "";
        String cvsSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // skip the header of the csv
            br.readLine();
            while ((line = br.readLine()) != null) {
                // use comma as separator
                String[] product = line.split(cvsSplitBy);
                menu.put(product[0], Float.parseFloat(product[1]));
            }

        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
    }


public void loadRooms() throws IOException, ParseException {
    csvFile = "C:/Users/PC/Documents/Proyect3DpoTryNo1000/app/src/main/java/proyect3dpotryno1000/Info/Rooms.csv";
    String line;
    String csvSplitBy = ",";

    try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
        br.readLine();  // Skipping the header

        while ((line = br.readLine()) != null) {
            String[] roomInfo = line.split(csvSplitBy);
            String roomNumber = roomInfo[0];
            Habitacion newRoom = null;

            switch (roomInfo[1]) {  // tipo
                case "standard":
                    newRoom = new StandardRoom(
                    roomInfo[1],             // tipo
                    Boolean.parseBoolean(roomInfo[2]),  // cocina
                    Boolean.parseBoolean(roomInfo[3]),  // balcon
                    Boolean.parseBoolean(roomInfo[4]),  // vista
                    roomInfo[5],             // torre
                    Integer.parseInt(roomInfo[6]),  // piso
                    roomInfo[7],             // id
                    Integer.parseInt(roomInfo[8]),  // tamanoHab
                    Boolean.parseBoolean(roomInfo[9]),  // aire_acondicionado
                    Boolean.parseBoolean(roomInfo[10]), // calefaccion
                    roomInfo[11],            // tamanoCama
                    Boolean.parseBoolean(roomInfo[12]), // tv
                    Boolean.parseBoolean(roomInfo[13]), // cafetera
                    Boolean.parseBoolean(roomInfo[14]), // ropCama_TapHipoaler
                    Boolean.parseBoolean(roomInfo[15]), // plancha
                    Boolean.parseBoolean(roomInfo[16]), // secadorPelo
                    Integer.parseInt(roomInfo[17]), // voltajeAC
                    Boolean.parseBoolean(roomInfo[18]), // tomaUSBA
                    Boolean.parseBoolean(roomInfo[19]), // tomaUSBC
                    Boolean.parseBoolean(roomInfo[20])  // incluyeDesayuno
                );

                    break;
                case "suite":
                    newRoom = new SuiteRoom(
                        roomInfo[1],             // tipo
                    Boolean.parseBoolean(roomInfo[2]),  // cocina
                    Boolean.parseBoolean(roomInfo[3]),  // balcon
                    Boolean.parseBoolean(roomInfo[4]),  // vista
                    roomInfo[5],             // torre
                    Integer.parseInt(roomInfo[6]),  // piso
                    roomInfo[7],             // id
                    Integer.parseInt(roomInfo[8]),  // tamanoHab
                    Boolean.parseBoolean(roomInfo[9]),  // aire_acondicionado
                    Boolean.parseBoolean(roomInfo[10]), // calefaccion
                    roomInfo[11],            // tamanoCama
                    Boolean.parseBoolean(roomInfo[12]), // tv
                    Boolean.parseBoolean(roomInfo[13]), // cafetera
                    Boolean.parseBoolean(roomInfo[14]), // ropCama_TapHipoaler
                    Boolean.parseBoolean(roomInfo[15]), // plancha
                    Boolean.parseBoolean(roomInfo[16]), // secadorPelo
                    Integer.parseInt(roomInfo[17]), // voltajeAC
                    Boolean.parseBoolean(roomInfo[18]), // tomaUSBA
                    Boolean.parseBoolean(roomInfo[19]), // tomaUSBC
                    Boolean.parseBoolean(roomInfo[20])  // incluyeDesayuno
                    );
                    break;
                case "double suite":
                    newRoom = new SuiteDoubleRoom(
                    roomInfo[1],             // tipo
                    Boolean.parseBoolean(roomInfo[2]),  // cocina
                    Boolean.parseBoolean(roomInfo[3]),  // balcon
                    Boolean.parseBoolean(roomInfo[4]),  // vista
                    roomInfo[5],             // torre
                    Integer.parseInt(roomInfo[6]),  // piso
                    roomInfo[7],             // id
                    Integer.parseInt(roomInfo[8]),  // tamanoHab
                    Boolean.parseBoolean(roomInfo[9]),  // aire_acondicionado
                    Boolean.parseBoolean(roomInfo[10]), // calefaccion
                    roomInfo[11],            // tamanoCama
                    Boolean.parseBoolean(roomInfo[12]), // tv
                    Boolean.parseBoolean(roomInfo[13]), // cafetera
                    Boolean.parseBoolean(roomInfo[14]), // ropCama_TapHipoaler
                    Boolean.parseBoolean(roomInfo[15]), // plancha
                    Boolean.parseBoolean(roomInfo[16]), // secadorPelo
                    Integer.parseInt(roomInfo[17]), // voltajeAC
                    Boolean.parseBoolean(roomInfo[18]), // tomaUSBA
                    Boolean.parseBoolean(roomInfo[19]), // tomaUSBC
                    Boolean.parseBoolean(roomInfo[20])  // incluyeDesayuno
                );
                    break;
            }

            if (newRoom != null) {
                rooms.put(roomNumber, newRoom);
            } else {
                System.out.println("Unknown room type for room number " + roomNumber);
            }
        }

    }
    catch (IOException e) {
        e.printStackTrace();
        throw e;
    }
}

    public HashMap<String, Float> getServices(){

        return services;
    }

    public HashMap<String, Float> getMenu(){

        return menu;
    }

    public HashMap<String, Float> getProducts(){

        return products; 

    }

    public HashMap<String, Habitacion> getRooms(){

        return rooms;
    }

    public HashMap<String, Account> getAccounts(){

        return accounts;
    }

    public HashMap<String, String> getAuthUsers(){

        return authUsers;
    }

    public ArrayList<Sale> getSales(){

        return sales;
    }
    public void setAuthUsers(String user, String password){

        authUsers.put(user, password);
    }

    public boolean setServices(String service, Float price){

        services.put(service, price);

        return true;
    }

    public boolean setProducts(String product, Float price){

        products.put(product, price);

        return true;
    }

    public boolean setRoom(Habitacion room, String number){

        rooms.put(number, room);

        return true;
    }

    public boolean setAccount(Account account, String roomNumber){

        accounts.put(roomNumber, account);

        return true;
    }

    public void loadAuthUsers() throws IOException, ParseException {
        csvFile = "C:/Users/PC/Documents/Proyect3DpoTryNo1000/app/src/main/java/proyect3dpotryno1000/Info/AuthUser.csv"; // specify the correct path to your CSV file
        String line = "";
        String csvSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // Skip the header line
            br.readLine();
            
            while ((line = br.readLine()) != null) {
                String[] userCredentials = line.split(csvSplitBy);
                String username = userCredentials[0].trim();
                String password = userCredentials[1].trim();

                // Adding the username-password pairs to the hashmap
                authUsers.put(username, password);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
    }

    public void loadSales() throws IOException, ParseException{
        csvFile = "C:/Users/PC/Documents/Proyect3DpoTryNo1000/app/src/main/java/proyect3dpotryno1000/Info/Restaurant.csv";

        try (BufferedReader br = Files.newBufferedReader(Paths.get(csvFile))) {
            // Read the first line from the text file which will be the header
            br.readLine();
            String line = br.readLine();

            // Loop until all lines are read
            while (line != null) {
                // use string.split to load a string array with the values from each line of
                // the file, using a comma as the delimiter
                String[] attributes = line.split(",");

                String date = attributes[0];
                List<String> items = Arrays.asList(attributes[1].split(";"));
                float price = Float.parseFloat(attributes[2]);

                sales.add(new Sale(date, items, price));

                line = br.readLine();
            }
        }

        catch (Exception e){

            e.printStackTrace();
            throw e;
        }

    }

    public void loadDatabase() throws IOException, ParseException {
        csvFile = "C:/Users/PC/Documents/Proyect3DpoTryNo1000/app/src/main/java/proyect3dpotryno1000/Info/Database.csv";
        String line = "";
        String cvsSplitBy = ",";
    
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // skip the header of the csv
            br.readLine();
            while ((line = br.readLine()) != null) {
                // use comma as separator
                String[] roomData = line.split(cvsSplitBy);
    
                String roomNumber = roomData[0];
                String state = roomData[1];
                String startDate = roomData[2];
                String endDate = roomData[3];
                float haveToPay = roomData[4].equals("-") ? 0 : Float.parseFloat(roomData[4]);
                String owner = roomData[5];
    
                Account account = new Account();
                account.setRoomNumber(roomNumber);
                account.setState(state);
                account.setStartDate(startDate.equals("-") ? null : new SimpleDateFormat("yyyy-MM-dd").parse(startDate));
                account.setEndDate(endDate.equals("-") ? null : new SimpleDateFormat("yyyy-MM-dd").parse(endDate));
                account.setHaveToPay(haveToPay);
                account.setOwner(owner);
    
                accounts.put(roomNumber, account);
            }
        }
    }
    

}




