package proyect3dpotryno1000.modelo;
import org.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;

public class PayU implements PaymentGateway {

    private Double fee;
    private Float amount;

    @Override
    public String processPayment(String cardInfo, Float amount) {

        fee = 0.1;
        this.amount = (float) (amount + (amount * fee));

        // Create a JSON object and put values
        JSONObject transaction = new JSONObject();
        transaction.put("cardinfo", cardInfo);
        transaction.put("amount", this.amount.toString());
        transaction.put("fee", fee.toString());
        transaction.put("status", "Payment done successfully");

        JSONObject logEntry = new JSONObject();
        logEntry.put("Gateway", "PayU");
        logEntry.put("Transaction", transaction);

        // Write JSON to file
        try (FileWriter file = new FileWriter("C:/Users/PC/Documents/Proyect3DpoTryNo1000/app/src/main/java/proyect3dpotryno1000/Info/Logs.json", true)) {
            file.write(logEntry.toString());
            file.write(System.lineSeparator());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "Payment done successfully";
    }
}
