package proyect3dpotryno1000.modelo;
import java.util.List;

public class Sale {
    private String date;
    private List<String> items;
    private float price;

    public Sale(String date, List<String> items, float price) {
        this.date = date;
        this.items = items;
        this.price = price;
    }

    public float getPrice(){


        return price;
    }

    public List<String> getItem(){

        return items;
    }

    public String getDate(){


        return date;
    }

    // getters and setters
}

