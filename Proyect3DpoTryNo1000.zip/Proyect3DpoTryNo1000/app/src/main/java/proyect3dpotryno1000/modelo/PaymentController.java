package proyect3dpotryno1000.modelo;
import java.lang.ClassNotFoundException;
import java.lang.NoSuchMethodException;
import java.lang.InstantiationException;
import java.lang.IllegalAccessException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class PaymentController {

    private String payMethod;
    private LoadInfoController loadInfoController;
    public PaymentController(LoadInfoController loadInfoController){

        this.loadInfoController = loadInfoController;

    }

    public String launchPayPlatform(String payMethod, String cardInfo, Float amount, String roomNumber) {
        this.payMethod = payMethod;
        String isSuccess = "There was a problem with your payment";
    
        try {
            Class<?> cls = Class.forName("proyect3dpotryno1000.modelo." + payMethod);
            PaymentGateway gateway = (PaymentGateway) cls.getDeclaredConstructor().newInstance();
            isSuccess = gateway.processPayment(cardInfo, amount);
            resetHaveToPay(roomNumber);

        } catch (ClassNotFoundException | NoSuchMethodException | InstantiationException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }

        return isSuccess;
    }

    public List<String> getAvailablePaymentGateways() {
        List<String> gateways = new ArrayList<>();
        try {
            gateways = Files.readAllLines(Paths.get("C:/Users/PC/Documents/Proyect3DpoTryNo1000/app/src/main/java/proyect3dpotryno1000/Info/PayGateways.txt"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return gateways;
    }

    public void resetHaveToPay(String roomNumber){

        loadInfoController.getAccounts().get(roomNumber).setHaveToPay((float)0);


    }
    
}
