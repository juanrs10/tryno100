package proyect3dpotryno1000.modelo;

import java.util.HashMap;
import java.util.Date;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ReservationHandler {

    
    public HashMap<String, Account> accounts;
    public HashMap<String, Habitacion> rooms;
    private Float suiteRate = (float)1000;
    private Float standardRate = (float)300; 
    private Float suiteDoubleRate = (float)600; 


    public ReservationHandler(LoadInfoController loadInfoController){


        this.accounts = loadInfoController.getAccounts();
        this.rooms = loadInfoController.getRooms();


    }

    public String confirmReservation(String roomNumber, Date startDate, Date endDate, String Owner) {
        // Check if roomNumber and dates are provided
        if (roomNumber != null && !roomNumber.isEmpty() && startDate != null && endDate != null) {
            // Check if the roomNumber exists in the hashmap
            if (!accounts.containsKey(roomNumber)) {
                return "Room number not found.";
            }
        
            Account account = accounts.get(roomNumber);
        
            // Check if the room is available
            if ("available".equalsIgnoreCase(account.getState())) {
                // Check if the room is free for the entire duration
                if ((account.getStartDate() == null || endDate.before(account.getStartDate()))
                    && (account.getEndDate() == null || startDate.after(account.getEndDate()))) {
                    account.setState("taken");
                    account.setStartDate(startDate);
                    account.setEndDate(endDate);
                    account.setOwner(Owner);
                    account.setHaveToPay(standardRate*(float)Math.abs(startDate.getTime()-endDate.getTime()));
                    return "Room " + roomNumber + " is available! reservation was done";
                } else {
                    return "Room " + roomNumber + " is not free for the entire duration.";
                }
            } else if ("taken".equalsIgnoreCase(account.getState())) {
                return "Room " + roomNumber + " is currently taken.";
            } else {
                return "Unknown state for room " + roomNumber + ".";
            }
        } else if (startDate != null && endDate != null) { // If only dates are provided, find all available rooms
            List<String> availableRooms = new ArrayList<>();
            for (Map.Entry<String, Account> entry : accounts.entrySet()) {
                Account account = entry.getValue();
                if ("available".equalsIgnoreCase(account.getState())
                    && (account.getStartDate() == null || endDate.before(account.getStartDate()))
                    && (account.getEndDate() == null || startDate.after(account.getEndDate()))) {
                    availableRooms.add(entry.getKey());
                }
            }
            return "Rooms available for the given period: " + availableRooms.toString();
        } else { // If no valid input is provided
            return "Please provide a room number and/or a valid date range.";
        }
    }

    public String cancelReservation(String roomNumber) {
        Account account = accounts.get(roomNumber);
    
        // Check if the account exists
        if(account == null) {
            return "There is no reservation for that room.";
        }
    
        // Check if the room is already available
        if(account.getState().equals("available")) {
            return "The room is already available, no reservation to cancel.";
        }
    
        // Check if the cancellation is being made less than 48 hours before the reservation start date
        Date now = new Date();
        long diffInMillies = Math.abs(account.getStartDate().getTime() - now.getTime());
        long diffInHours = TimeUnit.HOURS.convert(diffInMillies, TimeUnit.MILLISECONDS);
        
        if (diffInHours < 48) {
            return "You can only cancel 2 days before the reservation takes place.";
        }
    
        account.setStartDate(null);
        account.setEndDate(null);
        account.setHaveToPay(0f);
        account.setState("available");
        account.setOwner("-");
    
        return "Reservation cancelled successfully!";
    }

    public String setRate(Float rateSuite, Float rateStandard, Float rateSuiteDouble){


        this.suiteRate = rateSuite;
        this.standardRate = rateStandard;
        this.suiteDoubleRate = rateSuiteDouble;

        return "Rates have benn updated";
    }
    
    

    public String getRate(String roomNumber, Date startDate, Date endDate){

        Habitacion room = rooms.get(roomNumber);
    
        String type = room.getTipo();
    
        // Calculate difference in milliseconds
        long diffInMillis = Math.abs(endDate.getTime() - startDate.getTime());
    
        // Calculate difference in days
        long diffInDays = TimeUnit.DAYS.convert(diffInMillis, TimeUnit.MILLISECONDS);
    
        double totalCharge = 0;
    
        if (type.equals("suite")){
            totalCharge = diffInDays * suiteRate; // 1000 dollars per day
        } else if (type.equals("standard")){
            totalCharge = diffInDays * standardRate; // 300 dollars per day
        } else {
            totalCharge = diffInDays * suiteDoubleRate; // 600 dollars per day
        }

        Float haveToPay = accounts.get(roomNumber).getHaveToPay();

        accounts.get(roomNumber).setHaveToPay((float)(haveToPay+totalCharge));
    
        return String.valueOf(totalCharge); // Convert double to String and return
    }
    
    
}
