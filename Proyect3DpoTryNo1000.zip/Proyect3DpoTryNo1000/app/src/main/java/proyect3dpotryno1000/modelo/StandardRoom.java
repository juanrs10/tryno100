package proyect3dpotryno1000.modelo;

import java.util.ArrayList;

public class StandardRoom extends Habitacion
{
	private static final String TIPO = "estandar";
	private static final String[] TIPOS_CAMA = {Bed.getDouble()};
	
	public StandardRoom(String TIPO, boolean cocina, boolean balcon, boolean vista, String torre, int piso, String id, int tamanoHab, boolean aire_acondicionado, boolean calefaccion, String tamanoCama, boolean tv, boolean cafetera, boolean ropCama_TapHipoaler, boolean plancha, boolean secadorPelo, int voltajeAC, boolean tomaUSBA, boolean tomaUSBC, boolean incluyeDesayuno)
	{
		super(TIPO, cocina, balcon, vista, torre, piso, id, tamanoHab, aire_acondicionado, calefaccion, tamanoCama, tv, cafetera, ropCama_TapHipoaler, plancha, secadorPelo, voltajeAC, tomaUSBA, tomaUSBC, incluyeDesayuno);

		ArrayList<Bed> camas = new ArrayList<Bed>();
		for (String tipoCama : TIPOS_CAMA)
			camas.add(new Bed(tipoCama));
		super.setCamas(camas);
		
		int capacidadAdultos = 0;
		int capacidadNinos = 0;
		for (Bed cama : camas)
		{
			capacidadAdultos += cama.getAdultCapacity();
			capacidadNinos += cama.getChildCapacity();
		}
		super.setCapacidadAdultos(capacidadAdultos);
		super.setCapacidadNinios(capacidadNinos);
	}

}
