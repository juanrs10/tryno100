package proyect3dpotryno1000.modelo;

import org.checkerframework.checker.units.qual.A;
import java.util.Date;

public class AccountsController {

    private Account account;

    public void AccountsController(Account account){

        this.account = account;


    }

    public void charge(String serviceProduct, Float price){

        account.charge(serviceProduct, price);

    }

    public String generateBill(){

        return account.generateBill();
    }

    public void setRoomNumber(String roomNumber){


        account.setRoomNumber(roomNumber);
    }

    public void setState(String state){


       account.setState(state);
    }

    public void setStartDate(Date startDate){


        account.setStartDate(startDate);
    }

    public void setEndDate(Date endDate){


        account.setEndDate(endDate);
    }

    public void setHaveToPay(Float haveToPay){


        account.setHaveToPay(haveToPay);
    }

    public void setOwner(String owner){

        account.setOwner(owner);

    }

    public String getRoomNumber(){

        return account.getRoomNumber();

    }

    public String getState(){

        return account.getState();


    }

    public Date getStartDate(){

        return account.getStartDate();
        
    }

    public Date getEndDate(){

        return account.getEndDate();

    }

    public Float getHaveToPay(){

        return account.getHaveToPay();

    }

    public String getOwner(){

        return account.getOwner();

    }

    public float calculateHaveToPay() {
        return account.calculateHaveToPay();
    }
}
