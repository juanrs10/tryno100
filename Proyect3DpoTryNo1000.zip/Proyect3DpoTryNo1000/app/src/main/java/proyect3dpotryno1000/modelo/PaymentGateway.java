package proyect3dpotryno1000.modelo;

public interface PaymentGateway {

    String processPayment(String cardInfo,Float amount);
}

