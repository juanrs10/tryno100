package proyect3dpotryno1000.interfazAppHuesped;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import proyect3dpotryno1000.interfazGrafica.GatewayView;
import proyect3dpotryno1000.modelo.LoadInfoController;
import proyect3dpotryno1000.modelo.PaymentController;
import proyect3dpotryno1000.modelo.ReservationHandler;

public class GuestView extends JFrame implements ActionListener {
    private JButton checkAvailabilityButton, bookRoomButton, payButton;
    private JTextField startDateField, endDateField, roomNumberField, cardNumberField;
    private JTextArea guestInfoArea;
    private LoadInfoController loadInfoController;
    private ReservationHandler reservationHandler;
    private GatewayView gatewayView;
    private PaymentController paymentController;

    public GuestView(LoadInfoController loadInfoController) {
        this.loadInfoController = loadInfoController;
        this.paymentController = new PaymentController(loadInfoController);
        this.reservationHandler = new ReservationHandler(loadInfoController);

        setTitle("Guest View");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 300);
        setLayout(new GridBagLayout()); 

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;

        c.gridx = 0;
        c.gridy = 0;
        add(new JLabel("Start date:"), c);
        startDateField = new JTextField(15);
        c.gridx = 1;
        c.gridy = 0;
        add(startDateField, c);

        c.gridx = 0;
        c.gridy = 1;
        add(new JLabel("End date:"), c);
        endDateField = new JTextField(15);
        c.gridx = 1;
        c.gridy = 1;
        add(endDateField, c);

        checkAvailabilityButton = new JButton("Check Availability");
        checkAvailabilityButton.addActionListener(this);
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 2;
        add(checkAvailabilityButton, c);
        c.gridwidth = 1;

        c.gridx = 0;
        c.gridy = 3;
        add(new JLabel("Room number:"), c);
        roomNumberField = new JTextField(15);
        c.gridx = 1;
        c.gridy = 3;
        add(roomNumberField, c);

        c.gridx = 0;
        c.gridy = 4;
        add(new JLabel("Guest info:"), c);
        guestInfoArea = new JTextArea();
        c.gridx = 1;
        c.gridy = 4;
        c.weightx = 0.5;
        c.weighty = 0.5;
        c.gridheight = 2;
        add(new JScrollPane(guestInfoArea), c);
        c.gridheight = 1;
        c.gridx = 0;
        c.gridy = 7;
        add(new JLabel("Card number:"), c);
        cardNumberField = new JTextField(15);
        c.gridx = 1;
        c.gridy = 7;
        add(cardNumberField, c);

        payButton = new JButton("Pay Now");
        payButton.addActionListener(this);
        c.gridx = 0;
        c.gridy = 8;
        c.gridwidth = 2;
        add(payButton, c);

        pack();
        setVisible(true);
    }

    @Override
public void actionPerformed(ActionEvent e) {
    String command = e.getActionCommand();

    if (command.equals("Check Availability")) {
        String startDate = startDateField.getText();
        String endDate = endDateField.getText();
        String roomNumber = roomNumberField.getText();

        // Assuming your date format is in yyyy-mm-dd
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date startDateConverted, endDateConverted;

        try {
            startDateConverted = formatter.parse(startDate);
            endDateConverted = formatter.parse(endDate);
        } catch (ParseException pe) {
            // Handle exception
            JOptionPane.showMessageDialog(this, "Please enter dates in 'yyyy-mm-dd' format");
            return;
        }

        // Confirm Reservation
        String response = reservationHandler.confirmReservation(roomNumber, startDateConverted, endDateConverted, roomNumber);
        
        // Show response to the user
        JOptionPane.showMessageDialog(this, response);

    } else if (command.equals("Pay Now")) {
        String cardNumber = cardNumberField.getText();
        String roomNumber = roomNumberField.getText();
        
        PaymentController paymentController = new PaymentController(loadInfoController); // Assuming you have PaymentController class.

        // Create a GatewayView and show it
        GatewayView gatewayView = new GatewayView(loadInfoController, paymentController, roomNumber);
        gatewayView.setVisible(true);
    }
}

}
