package proyect3dpotryno1000.interfazAppHuesped;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import proyect3dpotryno1000.modelo.LoadInfoController;
import proyect3dpotryno1000.modelo.LoginController;

public class LoginGuestView extends JPanel implements ActionListener {
    private static final String REGISTRAR = "registrar";
    private static final String LOGIN = "login";
    private static final String LOGINPANEL = "loginPanel";
    private static final String REGISTERPANEL = "registerPanel";
    private static final String[] TIPOS_USUARIO = {"admin", "recepcionista", "empleado"}; 

    private JButton registerButton;
    private JButton loginButton;
    private Color backgroundColor;
    private Color foregroundColor;
    private Color buttonColor;
    private LoginController loginController;
    private LoadInfoController loadInfoController;

    private JTextField usernameField;
    private JPasswordField passwordField;

    private JTextField newUsernameField;
    private JPasswordField newPasswordField;
    private JButton confirmRegistrationButton;
    private static final String CONFIRM_REGISTRATION = "confirmRegistration";

    private CardLayout cardLayout;
    private JPanel cards;

    public LoginGuestView(LoadInfoController loadInfoController)
    {
        backgroundColor = new Color(25, 25, 25);  // Darker gray
        foregroundColor = new Color(255, 255, 255); // Bright white
        buttonColor = new Color(100, 100, 100); // Lighter gray for the button

        this.buttonColor = buttonColor;
        this.loadInfoController = loadInfoController;
        this.loginController = new LoginController(loadInfoController);

        cardLayout = new CardLayout();
        cards = new JPanel(cardLayout);

        JPanel loginPanel = createLoginPanel();
        cards.add(loginPanel, LOGINPANEL);

        JPanel registerPanel = createRegisterPanel();
        cards.add(registerPanel, REGISTERPANEL);

        add(cards);
    }

    private JPanel createLoginPanel() {
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(backgroundColor);
        loginPanel.setForeground(foregroundColor);
        loginPanel.setOpaque(true);

        GridBagConstraints c = new GridBagConstraints();

        JLabel usernameLabel = new JLabel("Username:");
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(10, 10, 10, 10);
        loginPanel.add(usernameLabel, c);

        usernameField = new JTextField(15);
        c.gridx = 1;
        c.gridy = 0;
        loginPanel.add(usernameField, c);

        JLabel passwordLabel = new JLabel("Password:");
        c.gridx = 0;
        c.gridy = 1;
        loginPanel.add(passwordLabel, c);

        passwordField = new JPasswordField(15);
        c.gridx = 1;
        c.gridy = 1;
        loginPanel.add(passwordField, c);

        registerButton = new JButton("Registrar nuevo usuario");
        registerButton.addActionListener(this);
        registerButton.setActionCommand(REGISTRAR);
        registerButton.setForeground(foregroundColor);
        registerButton.setBackground(buttonColor);
        registerButton.isEnabled();
        c.gridx = 0;
        c.gridy = 2;
        loginPanel.add(registerButton, c);

        loginButton = new JButton("Ingresar");
        loginButton.addActionListener(this);
        loginButton.setActionCommand(LOGIN);
        loginButton.setForeground(foregroundColor);
        loginButton.setBackground(buttonColor);
        c.gridx = 1;
        c.gridy = 2;
        loginPanel.add(loginButton, c);

        return loginPanel;
    }

    private JPanel createRegisterPanel() {
        JPanel registerPanel = new JPanel(new FlowLayout());
        registerPanel.setBackground(backgroundColor);
        registerPanel.setForeground(foregroundColor);

        registerPanel.add(new JLabel("New username:"));
        newUsernameField = new JTextField(15);
        registerPanel.add(newUsernameField);

        registerPanel.add(new JLabel("New password:"));
        newPasswordField = new JPasswordField(15);
        registerPanel.add(newPasswordField);

        confirmRegistrationButton = new JButton("Confirm Registration");
        confirmRegistrationButton.addActionListener(this);
        confirmRegistrationButton.setActionCommand(CONFIRM_REGISTRATION);
        confirmRegistrationButton.setForeground(foregroundColor);
        confirmRegistrationButton.setBackground(buttonColor);

        registerPanel.add(confirmRegistrationButton);

        return registerPanel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        if (command.equals(REGISTRAR)) {
            cardLayout.show(cards, REGISTERPANEL);
        } else if (command.equals(LOGIN)) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String role = loginController.authenticate(username, password);

            if (role.equals("client")){
                GuestView guestView = new GuestView(loadInfoController);
                guestView.setVisible(true);
            }
        } else if (command.equals(CONFIRM_REGISTRATION)) {
            String newUsername = newUsernameField.getText();
            String newPassword = new String(newPasswordField.getPassword());
            String message = loginController.register(newUsername, newPassword);

            JOptionPane.showMessageDialog(this, message);
            cardLayout.show(cards, LOGINPANEL); // return to login panel
        }
    }
}
