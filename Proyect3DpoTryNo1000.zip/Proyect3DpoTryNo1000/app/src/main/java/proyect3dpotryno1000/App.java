package proyect3dpotryno1000;

import proyect3dpotryno1000.interfazGrafica.LoginView;
import proyect3dpotryno1000.modelo.LoadInfoController;
import proyect3dpotryno1000.modelo.Resort;

import java.awt.Color;
import java.io.IOException;
import java.text.ParseException;

import javax.swing.JFrame;

import org.checkerframework.checker.units.qual.C;

import proyect3dpotryno1000.interfazGrafica.ChargeView;
import proyect3dpotryno1000.interfazGrafica.ReceptionistView;

public class App {


    private static Resort resort = new Resort();
    private static final LoadInfoController loadInfoController = new LoadInfoController(resort);
    private static  LoginView loginView;
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                // Load info
                try {
                    loadInfoController.loadInfo();
                } catch (IOException | ParseException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                
                // Create LoginView and add it to a JFrame
                LoginView loginView = new LoginView(loadInfoController);
                JFrame frame = new JFrame("Login");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.add(loginView);
                frame.pack();
                
                // Display the JFrame
                frame.setVisible(true);
            }
        });
    }
    
}


