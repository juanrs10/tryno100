package proyect3dpotryno1000.interfazGrafica;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import proyect3dpotryno1000.modelo.LoadInfoController;
import proyect3dpotryno1000.modelo.LoginController;

public class LoginView extends JPanel implements ActionListener {
    private static final String REGISTRAR = "registrar";
    private static final String LOGIN = "login";
    private static final String TIPO = "tipo";
    private static final String[] TIPOS_USUARIO = {"admin", "recepcionista", "empleado"}; 
    private static final String CONFIRM_REGISTRATION = "confirmRegistration";

    private JButton registerButton, confirmRegistrationButton;
    private JButton loginButton;
    private Color backgroundColor;
    private Color foregroundColor;
    private Color buttonColor;
    private LoginController loginController;
    private LoadInfoController loadInfoController;

    private JTextField usernameField,newUsernameField;
    private JPasswordField passwordField, newPasswordField;

    private CardLayout cardLayout = new CardLayout();
    private JPanel cards = new JPanel(cardLayout);

    public LoginView(LoadInfoController loadInfoController) {
        backgroundColor = new Color(25, 25, 25);
        foregroundColor = new Color(255, 255, 255);
        buttonColor = new Color(100, 100, 100);
        this.buttonColor = buttonColor;
        this.loadInfoController = loadInfoController;
        this.loginController = new LoginController(loadInfoController);

        JPanel loginPanel = createLoginPanel();
        cards.add(loginPanel, "LOGINPANEL");
        add(cards);
    }

    private JPanel createLoginPanel() {
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(backgroundColor);
        loginPanel.setForeground(foregroundColor);
        loginPanel.setOpaque(true);

        GridBagConstraints c = new GridBagConstraints();

        JLabel usernameLabel = new JLabel("Username:");
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(10, 10, 10, 10);
        loginPanel.add(usernameLabel, c);

        usernameField = new JTextField(15);
        c.gridx = 1;
        c.gridy = 0;
        loginPanel.add(usernameField, c);

        JLabel passwordLabel = new JLabel("Password:");
        c.gridx = 0;
        c.gridy = 1;
        loginPanel.add(passwordLabel, c);

        passwordField = new JPasswordField(15);
        c.gridx = 1;
        c.gridy = 1;
        loginPanel.add(passwordField, c);

        registerButton = new JButton("Registrar nuevo usuario");
        registerButton.addActionListener(this);
        registerButton.setActionCommand(REGISTRAR);
        registerButton.setForeground(foregroundColor);
        registerButton.setBackground(buttonColor);
        c.gridx = 0;
        c.gridy = 2;
        loginPanel.add(registerButton, c);

        loginButton = new JButton("Ingresar");
        loginButton.addActionListener(this);
        loginButton.setActionCommand(LOGIN);
        loginButton.setForeground(foregroundColor);
        loginButton.setBackground(buttonColor);
        c.gridx = 1;
        c.gridy = 2;
        loginPanel.add(loginButton, c);

        return loginPanel;
    }

    private JPanel createRegisterPanel() {
        JPanel registerPanel = new JPanel(new FlowLayout());
        registerPanel.setBackground(backgroundColor);
        registerPanel.setForeground(foregroundColor);

        registerPanel.add(new JLabel("New username:"));
        newUsernameField = new JTextField(15);
        registerPanel.add(newUsernameField);

        registerPanel.add(new JLabel("New password:"));
        newPasswordField = new JPasswordField(15);
        registerPanel.add(newPasswordField);

        confirmRegistrationButton = new JButton("Confirm Registration");
        confirmRegistrationButton.addActionListener(this);
        confirmRegistrationButton.setActionCommand(CONFIRM_REGISTRATION);
        confirmRegistrationButton.setForeground(foregroundColor);
        confirmRegistrationButton.setBackground(buttonColor);

        registerPanel.add(confirmRegistrationButton);

        return registerPanel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        if (command.equals(REGISTRAR)) {
            for (Component comp : cards.getComponents()) {
                if (comp.getName() != null && comp.getName().equals("REGISTERPANEL")) {
                    cardLayout.show(cards, "REGISTERPANEL");
                    return;
                }
            }

            JPanel registerPanel = createRegisterPanel();
            registerPanel.setName("REGISTERPANEL");
            cards.add(registerPanel, "REGISTERPANEL");
            cardLayout.show(cards, "REGISTERPANEL");
        } else if (command.equals(LOGIN)) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String role = loginController.authenticate(username, password);

            if (role.equals("manager")) {
                ManagerView managerView = new ManagerView(loadInfoController);
                managerView.setVisible(true);
            } else if (role.equals("receptionist")) {
                ReceptionistView receptionistView = new ReceptionistView(loadInfoController);
                receptionistView.setVisible(true);
            } else if (role.equals("employee")) {
                EmployeeView employeeView = new EmployeeView(loadInfoController);
                employeeView.setVisible(true);
            }
        }
    }
}
