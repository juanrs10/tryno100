package proyect3dpotryno1000.interfazGrafica;

import javax.swing.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import proyect3dpotryno1000.modelo.LoadInfoController;
import proyect3dpotryno1000.modelo.Resort;
import proyect3dpotryno1000.modelo.Restaurante;
import proyect3dpotryno1000.modelo.Sale;

import java.awt.GridLayout;
import java.util.ArrayList;

public class RestaurantGraph extends JFrame {
    private DefaultCategoryDataset dataset;
    private Restaurante restaurante;
    private LoadInfoController loadInfoController;

    public RestaurantGraph(LoadInfoController loadInfoController) {
        this.loadInfoController = loadInfoController;
        this.restaurante = new Restaurante(loadInfoController);
        this.dataset = createDataset();

        // Generate the charts
        JFreeChart barChart = ChartFactory.createBarChart(
                "Sales by Item",
                "Item",
                "Sales",
                dataset);

        JFreeChart lineChart = ChartFactory.createLineChart(
                "Sales over Time",
                "Date",
                "Sales",
                dataset);

        // Create panels to hold the charts
        ChartPanel barPanel = new ChartPanel(barChart);
        ChartPanel linePanel = new ChartPanel(lineChart);

        // Add charts to the JFrame
        this.setLayout(new GridLayout(2, 2));
        this.add(barPanel);
        this.add(linePanel);

        // Create and add indicators
        JLabel totalSalesIndicator = new JLabel("Total Sales: " + String.valueOf(restaurante.getTotalSales()));
        JLabel averageSalesIndicator = new JLabel("Average Daily Sales: " + String.valueOf(restaurante.getAverageSales()));
        this.add(totalSalesIndicator);
        this.add(averageSalesIndicator);

        // Set the size of the window
        this.setSize(800, 600);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setVisible(true);
    }

    private DefaultCategoryDataset createDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        ArrayList<Sale> sales = loadInfoController.getSales();

        // Populate the dataset with sales data
        for (Sale sale : sales) {
            for (String item : sale.getItem()) {
                dataset.addValue(sale.getPrice(), "Sales", item);
            }
        }

        return dataset;
    }
}
