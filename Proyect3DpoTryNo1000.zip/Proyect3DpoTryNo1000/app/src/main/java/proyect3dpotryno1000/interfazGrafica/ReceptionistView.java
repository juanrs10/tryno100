package proyect3dpotryno1000.interfazGrafica;
//DONE
//REDUCIR CARGA THE LA CLASE, QUITAR ELEMENTOS DE LOGICA
import java.awt.GridLayout;
import java.awt.Color;
import javax.swing.JComboBox;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Insets;
import java.awt.event.ActionListener;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import javax.swing.BoxLayout;
import proyect3dpotryno1000.interfazGrafica.ChargeView;
import proyect3dpotryno1000.modelo.LoadInfoController;
import proyect3dpotryno1000.modelo.ReservationHandler;

import java.awt.BorderLayout;
import javax.swing.border.EmptyBorder;
import javax.swing.JComponent;
import java.awt.GridBagLayout;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;


@SuppressWarnings("serial")

public class ReceptionistView extends JFrame implements ActionListener
{
	private LoadInfoController loadInfoController;
	private ReservationHandler reservationHandler;

    // Colors for the interface elements
    private Color backgroundColor;
    private Color textColor;
    private Color buttonColor;

    // Panels for organizing interface layout
    private JPanel southPanel;
    private JPanel centerPanel;
    private JPanel northPanel;

    // Labels and fields for guest information
    private JLabel guestNameLabel, guestSurnameLabel, guestIdLabel, guestEmailLabel;
    private JLabel startDateLabel, endDateLabel, guestCountLabel, standardRoomCountLabel, suiteRoomCountLabel, doubleRoomCountLabel;

    private JTextField guestNameField, guestSurnameField, guestIdField, guestEmailField,roomNumberField;
    private JTextField startDateField, endDateField;

    // Combo boxes for selecting room and guest counts
    private JComboBox<Integer> guestCountComboBox, standardRoomCountComboBox, suiteRoomCountComboBox, doubleRoomCountComboBox;

    // Frame for guest information
    private JFrame guestInfoFrame;


    // Action command strings
    private static final String ADD_RESERVATION = "Realizar reserva";
    private static final String CHECK_IN = "Check-In";
    private static final String CHECK_OUT = "Check-Out";
    private static final String CANCEL_RESERVE = "Cancelar reserva";



    // Buttons for interface actions
    private JButton makeReservationButton;
	private JButton cancelButton;
    private JButton checkOutButton;
	// Add this action command string at the top of your class.
	private static final String ADD_CHARGE = "Charge";

	// Add a new button for interface actions.
	private JButton chargeButton;
	
	public ReceptionistView(LoadInfoController loadInfoController) {

		this.loadInfoController = loadInfoController;
		this.reservationHandler = new ReservationHandler(loadInfoController);
		// Set up UI components and add them to the frame
		setupUIComponents();
		
		// Set frame attributes
		setFrameAttributes();
	}
	
	private void setupUIComponents() {
		setCenterPanel();
		setSouthPanel();
	
		setLayout(new BorderLayout());
		setBackground(backgroundColor);
		setForeground(textColor);
	
		add(centerPanel, BorderLayout.CENTER);
		add(southPanel, BorderLayout.SOUTH);
	}
	
	private void setFrameAttributes() {
		setTitle("Recepcionista");
		setSize(1000, 700);
		setLocationRelativeTo(null);  // Center the window on the screen
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	private void setCenterPanel() {
		centerPanel = initPanel();
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(5, 5, 5, 5);  // Padding around each component
	
		// Initialize your text fields
		guestNameField = createTextField();
		guestSurnameField = createTextField();
		guestIdField = createTextField();
		guestEmailField = createTextField();
		startDateField = createTextField();
		endDateField = createTextField();
		roomNumberField = createTextField();
	
		// Adding JLabel and JTextField pairs
		String[] labels = {"Name:", "LastName:", "Id:", "Email Address:", "Date Start:", "Date End:","Room number:"};
		JTextField[] textFields = {guestNameField, guestSurnameField, guestIdField, guestEmailField, startDateField, endDateField, roomNumberField};
	
		for (int i = 0; i < labels.length; i++) {
			JLabel label = createLabel(labels[i]);
			JTextField textField = textFields[i]; // Now you have reference to the same JTextField object
	
			addComponentToPanel(label, textField, i, c);
		}
	
		// Initialize your comboboxes
		guestCountComboBox = createComboBox();
		standardRoomCountComboBox = createComboBox();
		suiteRoomCountComboBox = createComboBox();
		doubleRoomCountComboBox = createComboBox();
	
		// Adding JComboBoxes for number of guests and rooms
		String[] comboBoxLabels = {"Number of people:", "Number of Standard Rooms", "Number of Suites", "Number of Double Rooms"};
		JComboBox<Integer>[] comboBoxes = new JComboBox[]{guestCountComboBox, standardRoomCountComboBox, suiteRoomCountComboBox, doubleRoomCountComboBox};
	
		for (int i = 0; i < comboBoxLabels.length; i++) {
			JLabel label = createLabel(comboBoxLabels[i]);
			JComboBox<Integer> comboBox = comboBoxes[i]; // Now you have reference to the same JComboBox object
	
			addComponentToPanel(label, comboBox, i + labels.length, c);  // Offset by the number of labels
		}
	}
	
	
	private JPanel initPanel() {
		JPanel panel = new JPanel();
		panel.setBorder(new EmptyBorder(10, 10, 10, 10)); // Add margin around the panel
		panel.setBackground(backgroundColor);
		panel.setForeground(textColor);
		panel.setLayout(new GridBagLayout());
		
		return panel;
	}
	
	private JLabel createLabel(String text) {
		JLabel label = new JLabel(text);
		label.setForeground(textColor);
		label.setBackground(backgroundColor);
		
		return label;
	}
	
	private JTextField createTextField() {
		JTextField textField = new JTextField(20);
		textField.setForeground(textColor);
		textField.setBackground(backgroundColor);
		
		return textField;
	}
	
	private JComboBox<Integer> createComboBox() {
		JComboBox<Integer> comboBox = new JComboBox<>();
		for (int f = 0; f <= 20; f++) {
			comboBox.addItem(f);
		}
	
		return comboBox;
	}
	
	private void addComponentToPanel(JComponent label, JComponent fieldOrComboBox, int row, GridBagConstraints c) {
		c.gridx = 0;
		c.gridy = row;
		centerPanel.add(label, c);
		c.gridx = 1;
		centerPanel.add(fieldOrComboBox, c);
	}
	
	
	private void setSouthPanel()
	{
		southPanel = new JPanel(new FlowLayout());
		southPanel.setBackground(backgroundColor);
		southPanel.setForeground(textColor);
		
		makeReservationButton = new JButton("Reserve");
        makeReservationButton.addActionListener(this);
        makeReservationButton.setActionCommand(ADD_RESERVATION);
        makeReservationButton.setBackground(buttonColor);

		cancelButton = new JButton("Cancel Reservation");
		cancelButton.addActionListener(this);
		cancelButton.setActionCommand(CANCEL_RESERVE);
		cancelButton.setBackground(buttonColor);
		southPanel.add(cancelButton);
        
        checkOutButton = new JButton("CheckOut");
        checkOutButton.addActionListener(this);
        checkOutButton.setActionCommand(CHECK_OUT);
        checkOutButton.setBackground(buttonColor);
        southPanel.add(checkOutButton);
		southPanel.add(makeReservationButton);

		chargeButton = new JButton("Charge");
		chargeButton.addActionListener(this);
		chargeButton.setActionCommand(ADD_CHARGE);
		chargeButton.setBackground(buttonColor);
		southPanel.add(chargeButton);

	}
	
	private JTextField createTextField(int columns) {
		JTextField textField = new JTextField(columns);
		textField.setForeground(backgroundColor);
		textField.setBackground(textColor);
		return textField;
	}
	@Override
	public void actionPerformed(ActionEvent e)
	{

		 String command = e.getActionCommand();
		if (command.equals(ADD_RESERVATION)) {   
			// Get the room number from user input
			String roomNumber = roomNumberField.getText();
			String dateStartStr = startDateField.getText();
			String dateEndStr = endDateField.getText();
			String owner = guestNameField.getText();
		
			// Check if roomNumber or owner is empty
			if(roomNumber.isEmpty()) {
				JOptionPane.showMessageDialog(southPanel, "Please enter the room number!");
				return; // Don't proceed further
			}
			if(owner.isEmpty()) {
				JOptionPane.showMessageDialog(southPanel, "Please enter the name of the guest!");
				return; // Don't proceed further
			}
		
			// Convert date strings to Date objects
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date dateStart = null, dateEnd = null;
			try {
				if (!dateStartStr.isEmpty()) {
					dateStart = formatter.parse(dateStartStr);
				}
				if (!dateEndStr.isEmpty()) {
					dateEnd = formatter.parse(dateEndStr);
				}
			} catch (ParseException e1) {
				JOptionPane.showMessageDialog(southPanel, "Invalid date format. Please use yyyy-MM-dd.");
				return; // Don't proceed further
			}

			// Get the rate
			String rate = reservationHandler.getRate(roomNumber, dateStart, dateEnd);

			// Show rate to user and ask for confirmation
			int input = JOptionPane.showConfirmDialog(southPanel, 
				"The reservation will have a cost of: " + rate + "\nDo you wish to proceed?", 
				"Confirm Reservation", JOptionPane.YES_NO_OPTION);

			// Proceed if user confirmed
			if (input == 0) {
				// Confirm the reservation using ReservationHandler
				String reservationStatus = reservationHandler.confirmReservation(roomNumber,dateStart,dateEnd,owner);

				// Based on the reservation status, show the appropriate dialog
				JOptionPane.showMessageDialog(southPanel, reservationStatus);
			} else {
				// Do nothing, user cancelled the reservation
			}
		}
		else if (command.equals(CHECK_OUT)){
        // Launch BillView interface on checkout
			BillView billView = new BillView(loadInfoController);
			billView.setVisible(true);
    	}

		else if (command.equals(ADD_CHARGE)) {
			ChargeView chargeView = new ChargeView(loadInfoController);
			chargeView.setVisible(true);
		}
		else if (command.equals(CANCEL_RESERVE)) {
			JTextField roomNumberField = new JTextField();
			JButton confirmButton = new JButton("Confirm");
			confirmButton.addActionListener(e1 -> {
				// On Confirm button click, cancel the reservation
				String roomNumber = roomNumberField.getText();
				
				if (roomNumber.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Please enter a room number!");
					return;
				}
		
				String message = reservationHandler.cancelReservation(roomNumber);
				
				// Check if the reservation is null (invalid room number)
				if (message.contains("there is no reservation")) {
					JOptionPane.showMessageDialog(null, "Invalid room number. Please try again.");
					return;
				}
				
				JOptionPane.showMessageDialog(null, message);
			});
		
			Object[] message = {
				"Enter the room number to cancel the reservation:", roomNumberField,
				confirmButton
			};
		
			JOptionPane.showConfirmDialog(null, message, "Cancel Reservation", JOptionPane.OK_CANCEL_OPTION);
		}
		
		else	
		{
			
			JOptionPane.showMessageDialog(southPanel, "Checkout completed!");
		
	    }

}

}