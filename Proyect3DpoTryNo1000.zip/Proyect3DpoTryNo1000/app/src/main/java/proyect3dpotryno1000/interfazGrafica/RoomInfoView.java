package proyect3dpotryno1000.interfazGrafica;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import proyect3dpotryno1000.modelo.LoadInfoController;

public class RoomInfoView extends JFrame {

    private JTextField roomNumberField;
    private LoadInfoController loadInfoController;

    public RoomInfoView(LoadInfoController loadInfoController) {
        this.loadInfoController = loadInfoController;
        setTitle("Room Information");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(3, 1));

        roomNumberField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String roomNumber = roomNumberField.getText();
                String roomInfo = RoomInfoView.this.loadInfoController.searchRoom(roomNumber);
                displayRoomInfo(roomInfo);
            }
        });

        add(roomNumberField);
        add(searchButton);
    }

    private void displayRoomInfo(String roomInfo) {
        JTextArea textArea = new JTextArea(roomInfo);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane);
        revalidate();
        repaint();
    }
}
