package proyect3dpotryno1000.interfazGrafica;
import javax.swing.*;

import proyect3dpotryno1000.modelo.Account;
import proyect3dpotryno1000.modelo.Habitacion;
import proyect3dpotryno1000.modelo.LoadInfoController;
import proyect3dpotryno1000.modelo.Resort;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class ChargeView extends JFrame implements ActionListener {
    private JTextField roomNumberField;
    private JComboBox<String> serviceProductBox;
    private JButton confirmButton;
    private LoadInfoController loadInfoController;
    private HashMap<String,Float> serviceProductMap = new HashMap<>(); // HashMap to store both services and products

    private static final String CONFIRM = "Confirm";

    public ChargeView(LoadInfoController loadInfoController) {

        this.loadInfoController = loadInfoController;
        serviceProductMap = loadInfoController.getServiceProductMap();
        setLayout(new GridLayout(3, 2));

        add(new JLabel("Room Number: "));
        roomNumberField = new JTextField(20);
        add(roomNumberField);

        add(new JLabel("Service/Product: "));

        serviceProductBox = new JComboBox<>(serviceProductMap.keySet().toArray(new String[0]));
        serviceProductBox.addActionListener(e -> {
            String item = (String) serviceProductBox.getSelectedItem();
            float price = serviceProductMap.get(item);
            JOptionPane.showMessageDialog(this, "The total price for " + item + " is " + price);
        });
        add(serviceProductBox);

        confirmButton = new JButton("Confirm");
        confirmButton.addActionListener(this);
        confirmButton.setActionCommand(CONFIRM);
        add(confirmButton);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals(CONFIRM)) {
            String roomNumber = null;
            try {
                roomNumber = roomNumberField.getText();
            } catch (NumberFormatException ex) {
                ex.printStackTrace();
                // Handle invalid input for room number here, if needed
            }

            // Get the selected service/product name
            String serviceProduct = (String) serviceProductBox.getSelectedItem();

            // Call confirmCharge to update the HaveToPay field in the Database.csv file
            if (roomNumber != null && serviceProduct != null) {
                String result = loadInfoController.confirmCharge(roomNumber, serviceProduct);
                // You can use the returned result here to confirm that the charge was successful, if needed
                JOptionPane.showMessageDialog(null, result);
            }
        }
    }
}
