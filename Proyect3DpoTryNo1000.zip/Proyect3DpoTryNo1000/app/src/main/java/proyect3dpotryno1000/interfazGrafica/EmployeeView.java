package proyect3dpotryno1000.interfazGrafica;

import javax.swing.*;

import proyect3dpotryno1000.modelo.LoadInfoController;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import proyect3dpotryno1000.interfazGrafica.ChargeView;

public class EmployeeView extends JFrame {
    
    private JButton chargeButton;
    private JPanel panel;

    public EmployeeView(LoadInfoController loadInfoController) {
        super("Employee Interface");

        panel = new JPanel(new BorderLayout());

        chargeButton = new JButton("Charge");
        chargeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Here, replace with the correct loadInfoController you use in your application.
                ChargeView chargeView = new ChargeView(loadInfoController);
                chargeView.setVisible(true);
            }
        });

        panel.add(chargeButton, BorderLayout.CENTER);

        this.setContentPane(panel);
        this.setSize(300, 200);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

}