package proyect3dpotryno1000.interfazGrafica;

import proyect3dpotryno1000.modelo.LoadInfoController;
import proyect3dpotryno1000.modelo.PaymentController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class GatewayView extends JFrame {
    private LoadInfoController loadInfoController;
    private String documento;
    private String fechaInicial;
    private PaymentController paymentController;
    private Float amount;

    public GatewayView(LoadInfoController loadInfoController, PaymentController paymentController, String roomNumber) {
        this.loadInfoController = loadInfoController;
        this.paymentController = paymentController;
        this.amount = loadInfoController.getAccounts().get(roomNumber).getHaveToPay();

        this.documento = documento;
        this.fechaInicial = fechaInicial;

        setTitle("Payment Methods");
        setSize(300, 200);
        setLocationRelativeTo(null);

        // Get payment methods from the controller
        List<String> paymentMethods = paymentController.getAvailablePaymentGateways();
        JList<String> paymentMethodsList = new JList<>(paymentMethods.toArray(new String[0]));

        paymentMethodsList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selectedMethod = paymentMethodsList.getSelectedValue();

                JFrame paymentFrame = new JFrame("Payment with " + selectedMethod);
                paymentFrame.setSize(300, 200);
                paymentFrame.setLocationRelativeTo(null);

                JTextField cardNumberField = new JTextField(20);
                JButton payButton = new JButton("Pay");

                payButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        // Here you would call the paymentController's method to process the payment
                        // and show the response in a JOptionPane
                        String cardNumber = cardNumberField.getText();
                         // You should have the amount to pay from somewhere
                        String response = paymentController.launchPayPlatform(selectedMethod, cardNumber, amount,roomNumber);
                        JOptionPane.showMessageDialog(paymentFrame, response);
                    }
                });

                paymentFrame.getContentPane().setLayout(new BorderLayout());

                // create a label to display total amount
                JLabel totalAmountLabel = new JLabel("Total Amount to Pay: " + amount.toString());
                paymentFrame.getContentPane().add(totalAmountLabel, BorderLayout.PAGE_START);

                // set prompt for card number input
                cardNumberField.setToolTipText("Enter Card Number");
                paymentFrame.getContentPane().add(cardNumberField, BorderLayout.CENTER);

                paymentFrame.getContentPane().add(payButton, BorderLayout.PAGE_END);

                paymentFrame.setVisible(true);

            }
        });

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(paymentMethodsList, BorderLayout.CENTER);
    }
}
