package proyect3dpotryno1000.interfazGrafica;
//DONE
import java.awt.GridLayout;
import java.awt.Color;
import javax.swing.JComboBox;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import javax.swing.BoxLayout;
import java.awt.BorderLayout;
import javax.swing.JComponent;
import java.awt.GridBagLayout;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import proyect3dpotryno1000.interfazGrafica.GatewayView;
import proyect3dpotryno1000.modelo.LoadInfoController;
import proyect3dpotryno1000.modelo.PaymentController;
import proyect3dpotryno1000.modelo.Account;
import javax.swing.JTextArea;

public class BillView extends JFrame implements ActionListener {
    private LoadInfoController loadInfoController;
    private PaymentController paymentController;
    private JTextField roomNumberField;
    private JButton fetchBillButton;
    private JTable expensesTable;
    private JButton payButton;

    public BillView(LoadInfoController loadInfoController) {
        this.loadInfoController = loadInfoController;
        this.paymentController = new PaymentController(loadInfoController);

        setTitle("Bill View");
        setSize(500, 300); // You may want to increase the size of the frame
        setLocationRelativeTo(null);

        JPanel topPanel = new JPanel(new BorderLayout());
        roomNumberField = new JTextField();
        fetchBillButton = new JButton("Fetch Bill");
        fetchBillButton.addActionListener(e -> fetchBill());

        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Room Number: "));
        inputPanel.add(roomNumberField);

        topPanel.add(inputPanel, BorderLayout.CENTER);
        topPanel.add(fetchBillButton, BorderLayout.EAST);

        expensesTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(expensesTable);
        expensesTable.setFillsViewportHeight(true);

        payButton = new JButton("Pay");
        payButton.addActionListener(this);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(topPanel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        getContentPane().add(payButton, BorderLayout.SOUTH);
        topPanel.setBorder(new EmptyBorder(10, 10, 10, 10)); // Add padding to topPanel
    }

    private void fetchBill() {
        String roomNumber = roomNumberField.getText();
    
        if (roomNumber.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a room number!");
            return; // Don't proceed further
        }
    
        String billText = loadInfoController.chargeBill(roomNumber);
    
        // Show the fetched bill in a dialog
        JTextArea textArea = new JTextArea(billText);
        textArea.setEditable(false);
        JOptionPane.showMessageDialog(this, textArea, "Bill for Room " + roomNumber, JOptionPane.INFORMATION_MESSAGE);
    }
    

    @Override
public void actionPerformed(ActionEvent e) {
    // On Pay button press, launch PaymentMethodsView
    String roomNumber = roomNumberField.getText();

    // Check if the field is empty
    if(roomNumber.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please enter a room number!");
        return;
    }

    // Check if the field is a number
    try {
        Integer.parseInt(roomNumber);
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Please enter a valid room number!");
        return;
    }

    GatewayView gatewayView = new GatewayView(loadInfoController, paymentController, roomNumber);
    gatewayView.setVisible(true);
}

}
