package  proyect3dpotryno1000.interfazGrafica;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.Color;
import proyect3dpotryno1000.modelo.LoadInfoController;
import java.util.HashMap;
import java.time.LocalDate;
import java.time.YearMonth;

public class MatrixPanel extends JPanel {

    private LoadInfoController loadInfoController;
    private HashMap<String, Float> occupancyMap;

    public MatrixPanel(LoadInfoController loadInfoController) {
        this.loadInfoController = loadInfoController;
        occupancyMap = loadInfoController.calculateOccupancy();

        // Get the current date and the number of days in the current month
        LocalDate currentDate = LocalDate.now();
        YearMonth yearMonth = YearMonth.now();
        int daysInMonth = yearMonth.lengthOfMonth();
        
        // Find out which day of the week the first day of the month is
        int firstDayOfWeek = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1).getDayOfWeek().getValue();
        
        // Calculate the number of rows needed for the GridLayout (weeks in a month)
        int weeksInMonth = (int) Math.ceil((daysInMonth + firstDayOfWeek - 1) / 7.0);

        // Set GridLayout with seven columns (for each day of the week) and as many rows as there are weeks in the month
        this.setLayout(new GridLayout(weeksInMonth, 7));

        // Add "empty" panels for the days before the first day of the month
        for (int i = 1; i < firstDayOfWeek; i++) {
            this.add(new JPanel());
        }

        // Create a panel for each day with a color corresponding to its occupancy rate
        for (int day = 1; day <= daysInMonth; day++) {
            JPanel dayPanel = new JPanel(new BorderLayout());
            JLabel dayLabel = new JLabel(String.valueOf(day), SwingConstants.CENTER);
            dayPanel.add(dayLabel, BorderLayout.CENTER);
            
            String dateKey = currentDate.withDayOfMonth(day).toString();
            float occupancyRate = occupancyMap.getOrDefault(dateKey, 0f);

            // Set the panel's background color based on the occupancy rate
            dayPanel.setBackground(getColorForOccupancyRate(occupancyRate));
            this.add(dayPanel);
        }
    }

    // You can define your own function to map occupancy rates to colors
    private Color getColorForOccupancyRate(float occupancyRate) {
        if (occupancyRate < 33) {
            return Color.GREEN;
        } else if (occupancyRate < 66) {
            return Color.YELLOW;
        } else {
            return Color.RED;
        }
    }
}
