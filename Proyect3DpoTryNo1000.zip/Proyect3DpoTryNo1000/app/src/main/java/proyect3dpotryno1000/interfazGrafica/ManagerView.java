    package proyect3dpotryno1000.interfazGrafica;

    import javax.swing.JButton;
    import javax.swing.JCheckBox;
    import javax.swing.JComboBox;
    import javax.swing.JFrame;
    import javax.swing.JLabel;
    import javax.swing.JPanel;
    import javax.swing.JTextField;
    import javax.swing.JOptionPane;
    import java.awt.event.ActionListener;
    import java.text.ParseException;
    import java.awt.GridLayout;
    import java.awt.event.ActionEvent;
    import proyect3dpotryno1000.modelo.LoadInfoController;
    import proyect3dpotryno1000.modelo.ReservationHandler;
    import java.awt.BorderLayout;
    import java.awt.FlowLayout;
    import java.awt.Color;

    @SuppressWarnings("serial")

    public class ManagerView extends JFrame implements ActionListener{

        private JFrame frame;
        private JPanel panel;
        private JButton createButton;
        private JButton showRestaurant;
        private JButton editButton;
        private JButton checkInventoryButton;
        private JButton adjustRatesButton;
        private LoadInfoController loadInfoController;
        private ReservationHandler reservationHandler;

        public ManagerView(LoadInfoController loadInfoController) {
            this.loadInfoController = loadInfoController;
            this.reservationHandler = new ReservationHandler(loadInfoController);
            setTitle("Manager View");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
            panel = new JPanel();
            panel.setLayout(new BorderLayout());
        
            JPanel buttonPanel = new JPanel();
            buttonPanel.setLayout(new FlowLayout());
        
            createButton = new JButton("Create");
            createButton.addActionListener(this);

            showRestaurant = new JButton("Restaurant stats");
            showRestaurant.addActionListener(this);
        
            editButton = new JButton("Edit");
            editButton.addActionListener(this);
        
            checkInventoryButton = new JButton("Check Inventory");
            checkInventoryButton.addActionListener(this);
        
            adjustRatesButton = new JButton("Adjust Rates");
            adjustRatesButton.addActionListener(this);
        
            buttonPanel.add(createButton);
            buttonPanel.add(editButton);
            buttonPanel.add(checkInventoryButton);
            buttonPanel.add(adjustRatesButton);
            buttonPanel.add(showRestaurant);

        
            panel.add(buttonPanel, BorderLayout.NORTH);
        
            // Create and add MatrixPanel
            MatrixPanel matrixPanel = new MatrixPanel(loadInfoController);
            panel.add(matrixPanel, BorderLayout.CENTER);
        
            // Create occupancy rate legend
            JPanel legendPanel = new JPanel();
            legendPanel.setLayout(new FlowLayout());
        
            JLabel greenLabel = new JLabel("< 33% Occupancy");
            greenLabel.setForeground(Color.GREEN);
            JLabel yellowLabel = new JLabel("33% - 66% Occupancy");
            yellowLabel.setForeground(Color.YELLOW);
            JLabel redLabel = new JLabel("> 66% Occupancy");
            redLabel.setForeground(Color.RED);
        
            legendPanel.add(greenLabel);
            legendPanel.add(yellowLabel);
            legendPanel.add(redLabel);
        
            panel.add(legendPanel, BorderLayout.SOUTH);
        
            getContentPane().add(panel);
            pack();
            setVisible(true);
        }
        

        private void showInventoryOptions() {
            JFrame inventoryFrame = new JFrame("Inventory Options");
            inventoryFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            JPanel inventoryPanel = new JPanel();
            inventoryPanel.setLayout(null);

            String[] options = {"Rooms", "Services", "Products", "Menu"};
            JComboBox<String> optionsComboBox = new JComboBox<>(options);
            optionsComboBox.setBounds(10, 10, 240, 30);

            JComboBox<String> itemComboBox = new JComboBox<>();
            itemComboBox.setBounds(10, 50, 240, 30);

            JButton checkButton = new JButton("Check");
            checkButton.setBounds(170, 90, 80, 30);

            optionsComboBox.addActionListener(e -> {
                String selectedOption = (String) optionsComboBox.getSelectedItem();
                itemComboBox.removeAllItems();

                if (selectedOption.equals("Rooms")) {
                    for (String roomNumber : loadInfoController.getRooms().keySet()) {
                        itemComboBox.addItem(roomNumber);
                    }
                } else if (selectedOption.equals("Services")) {
                    for (String service : loadInfoController.getServices().keySet()) {
                        itemComboBox.addItem(service);
                    }
                } else if (selectedOption.equals("Products")) {
                    for (String product : loadInfoController.getProducts().keySet()) {
                        itemComboBox.addItem(product);
                    }
                } else if (selectedOption.equals("Menu")) {
                    for (String menuItem : loadInfoController.getMenu().keySet()) {
                        itemComboBox.addItem(menuItem);
                    }
                }
            });

            checkButton.addActionListener(e -> {
                String selectedOption = (String) optionsComboBox.getSelectedItem();
                String selectedItem = (String) itemComboBox.getSelectedItem();
                String summary = "";

                if (selectedOption.equals("Rooms")) {
                    summary = loadInfoController.getRoomsSummary(selectedItem);
                } else if (selectedOption.equals("Services")) {
                    summary = loadInfoController.getServicesSummary(selectedItem);
                } else if (selectedOption.equals("Products")) {
                    summary = loadInfoController.getProductsSummary(selectedItem);
                } else if (selectedOption.equals("Menu")) {
                    summary = loadInfoController.getMenuSummary(selectedItem);
                }

                // Display the summary on the screen (e.g., show it in a dialog box)
                JOptionPane.showMessageDialog(inventoryFrame, summary, "Inventory Summary", JOptionPane.INFORMATION_MESSAGE);

                inventoryFrame.dispose();
            });

            inventoryPanel.add(optionsComboBox);
            inventoryPanel.add(itemComboBox);
            inventoryPanel.add(checkButton);

            inventoryFrame.getContentPane().add(inventoryPanel);
            inventoryFrame.setSize(270, 130);
            inventoryFrame.setVisible(true);
        }

        private void showEditScreen(String selectedItem) {
            JFrame editFrame = new JFrame("Edit Habitacion");
            editFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
            JPanel editPanel = new JPanel();
            editPanel.setLayout(new GridLayout(0, 2)); // Using GridLayout for simplicity
        
            JLabel typeLabel = new JLabel("Type:");
            JTextField tipoField = new JTextField();
            
            JLabel towerLabel = new JLabel("Tower:");
            JTextField towerField = new JTextField();
        
            JLabel floorLabel = new JLabel("Floor:");
            JTextField floorField = new JTextField();

            JLabel idLabel = new JLabel("ID:");
            JTextField idField = new JTextField();
            
            JLabel capacityLabel = new JLabel("Capacity - Adults: ");
            JTextField capacityField = new JTextField();
        
            JLabel sizeLabel = new JLabel("Room size:");
            JTextField sizeField = new JTextField();

            JLabel hasKitchenLabel = new JLabel("Has kitchen:");
            JCheckBox hasKitchenCheckBox = new JCheckBox();

            JLabel hasBalconyLabel = new JLabel("Has balcony:");
            JCheckBox hasBalconyCheckBox = new JCheckBox();

            JLabel hasViewLabel = new JLabel("Has View:");
            JCheckBox hasViewCheckBox = new JCheckBox();

            JLabel hasACLabel = new JLabel("Has AC:");
            JCheckBox hasACCheckBox = new JCheckBox();

            JLabel  hasHeatingLabel = new JLabel("Has heating:");
            JCheckBox hasHeatinCheckBox = new JCheckBox();

            JLabel bedSizeLabel = new JLabel("Bed size:");
            JTextField bedSizeField = new JTextField();

            JLabel hasTVLabel = new JLabel("Has TV:");
            JCheckBox hasTVCheckBox = new JCheckBox();

            JLabel hasCofeeLabel = new JLabel("Has coofee maker:");
            JCheckBox hasCofeeCheckBox = new JCheckBox();

            JLabel hasHypoLabel = new JLabel("Has hypoallergenic bedding::");
            JCheckBox hasHypoCheckBox = new JCheckBox();

            JLabel hasIronLabel = new JLabel("Has iron:");
            JCheckBox hasIronCheckBox = new JCheckBox();

            JLabel hasHairLabel = new JLabel("Has hair dryer:");
            JCheckBox hasHairCheckBox = new JCheckBox();

            JLabel ACVLabel = new JLabel("AC voltage:");
            JTextField ACVField = new JTextField();

            JLabel hasBreakfastLabel = new JLabel("Has breakfast included:");
            JCheckBox hasBreakfastCheckBox = new JCheckBox();//
        
            
            JButton confirmButton = new JButton("Confirm");
            confirmButton.addActionListener(e -> {
                String tipo = tipoField.getText();
                String tower = towerField.getText();
                String floor = floorField.getText();
                String id = idField.getText();
                String capacity = capacityField.getText();
                String roomSize = sizeField.getText();
                boolean hasKitchen = hasKitchenCheckBox.isSelected();
                boolean hasBalcony = hasBalconyCheckBox.isSelected();
                boolean hasView = hasViewCheckBox.isSelected();
                boolean hasAC = hasACCheckBox.isSelected();
                boolean hasHeating = hasHeatinCheckBox.isSelected();
                String bedSize = bedSizeField.getText();
                boolean hasTV = hasTVCheckBox.isSelected();
                boolean hasCofeeMaker = hasCofeeCheckBox.isSelected();
                boolean hasHypoallergenicBedding = hasHypoCheckBox.isSelected();
                boolean hasIron = hasIronCheckBox.isSelected();
                boolean hasHairDryer = hasHairCheckBox.isSelected();
                String ACVoltage = ACVField.getText();
                boolean hasBreakfastIncluded = hasBreakfastCheckBox.isSelected();

                // Call the method to edit the Habitacion
                String response = loadInfoController.editRoom(selectedItem, tipo, tower, floor, id, capacity, roomSize, hasKitchen, hasBalcony, hasView, hasAC, hasHeating, bedSize, hasTV, hasCofeeMaker, hasHypoallergenicBedding, hasIron, hasHairDryer, ACVoltage, hasBreakfastIncluded);
                JOptionPane.showMessageDialog(null, response);
                editFrame.dispose();
            });

            editPanel.add(typeLabel);
            editPanel.add(tipoField);
            editPanel.add(towerLabel);
            editPanel.add(towerField);
            editPanel.add(floorLabel);
            editPanel.add(floorField);
            editPanel.add(idLabel);
            editPanel.add(idField);
            editPanel.add(capacityLabel);
            editPanel.add(capacityField);
            editPanel.add(sizeLabel);
            editPanel.add(sizeField);
            editPanel.add(hasKitchenLabel);
            editPanel.add(hasKitchenCheckBox);
            editPanel.add(hasBalconyLabel);
            editPanel.add(hasBalconyCheckBox);
            editPanel.add(hasViewLabel);
            editPanel.add(hasViewCheckBox);
            editPanel.add(hasACLabel);
            editPanel.add(hasACCheckBox);
            editPanel.add(hasHeatingLabel);
            editPanel.add(hasHeatinCheckBox);
            editPanel.add(bedSizeLabel);
            editPanel.add(bedSizeField);
            editPanel.add(hasTVLabel);
            editPanel.add(hasTVCheckBox);
            editPanel.add(hasCofeeLabel);
            editPanel.add(hasCofeeCheckBox);
            editPanel.add(hasHypoLabel);
            editPanel.add(hasHypoCheckBox);
            editPanel.add(hasIronLabel);
            editPanel.add(hasIronCheckBox);
            editPanel.add(hasHairLabel);
            editPanel.add(hasHairCheckBox);
            editPanel.add(ACVLabel);
            editPanel.add(ACVField);
            editPanel.add(hasBreakfastLabel);
            editPanel.add(hasBreakfastCheckBox);

            editPanel.add(confirmButton);

            editFrame.getContentPane().add(editPanel);
            editFrame.pack();
            editFrame.setLocationRelativeTo(null);
            editFrame.setVisible(true);
    }

    private void showCreateScreen(String selectedItem) {
        JFrame editFrame = new JFrame("Create Room");
        editFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel editPanel = new JPanel();
        editPanel.setLayout(new GridLayout(0, 2)); // Using GridLayout for simplicity

        JLabel typeLabel = new JLabel("Type:");
        JTextField tipoField = new JTextField();
        
        JLabel towerLabel = new JLabel("Tower:");
        JTextField towerField = new JTextField();

        JLabel floorLabel = new JLabel("Floor:");
        JTextField floorField = new JTextField();

        JLabel idLabel = new JLabel("ID:");
        JTextField idField = new JTextField();
        
        JLabel capacityLabel = new JLabel("Capacity - Adults: ");
        JTextField capacityField = new JTextField();

        JLabel sizeLabel = new JLabel("Room size:");
        JTextField sizeField = new JTextField();

        JLabel hasKitchenLabel = new JLabel("Has kitchen:");
        JCheckBox hasKitchenCheckBox = new JCheckBox();

        JLabel hasBalconyLabel = new JLabel("Has balcony:");
        JCheckBox hasBalconyCheckBox = new JCheckBox();

        JLabel hasViewLabel = new JLabel("Has View:");
        JCheckBox hasViewCheckBox = new JCheckBox();

        JLabel hasACLabel = new JLabel("Has AC:");
        JCheckBox hasACCheckBox = new JCheckBox();

        JLabel  hasHeatingLabel = new JLabel("Has heating:");
        JCheckBox hasHeatinCheckBox = new JCheckBox();

        JLabel bedSizeLabel = new JLabel("Bed size:");
        JTextField bedSizeField = new JTextField();

        JLabel hasTVLabel = new JLabel("Has TV:");
        JCheckBox hasTVCheckBox = new JCheckBox();

        JLabel hasCofeeLabel = new JLabel("Has coofee maker:");
        JCheckBox hasCofeeCheckBox = new JCheckBox();

        JLabel hasHypoLabel = new JLabel("Has hypoallergenic bedding::");
        JCheckBox hasHypoCheckBox = new JCheckBox();

        JLabel hasIronLabel = new JLabel("Has iron:");
        JCheckBox hasIronCheckBox = new JCheckBox();

        JLabel hasHairLabel = new JLabel("Has hair dryer:");
        JCheckBox hasHairCheckBox = new JCheckBox();

        JLabel ACVLabel = new JLabel("AC voltage:");
        JTextField ACVField = new JTextField();

        JLabel hasBreakfastLabel = new JLabel("Has breakfast included:");
        JCheckBox hasBreakfastCheckBox = new JCheckBox();//

        
        JButton confirmButton = new JButton("Confirm");
        confirmButton.addActionListener(e -> {
            String tipo = tipoField.getText();
            String tower = towerField.getText();
            String floor = floorField.getText();
            String id = idField.getText();
            String capacity = capacityField.getText();
            String roomSize = sizeField.getText();
            boolean hasKitchen = hasKitchenCheckBox.isSelected();
            boolean hasBalcony = hasBalconyCheckBox.isSelected();
            boolean hasView = hasViewCheckBox.isSelected();
            boolean hasAC = hasACCheckBox.isSelected();
            boolean hasHeating = hasHeatinCheckBox.isSelected();
            String bedSize = bedSizeField.getText();
            boolean hasTV = hasTVCheckBox.isSelected();
            boolean hasCofeeMaker = hasCofeeCheckBox.isSelected();
            boolean hasHypoallergenicBedding = hasHypoCheckBox.isSelected();
            boolean hasIron = hasIronCheckBox.isSelected();
            boolean hasHairDryer = hasHairCheckBox.isSelected();
            String ACVoltage = ACVField.getText();
            boolean hasBreakfastIncluded = hasBreakfastCheckBox.isSelected();

            // Call the method to edit the Habitacion
            String response = loadInfoController.createRoom(selectedItem, tipo, tower, floor, id, capacity, roomSize, hasKitchen, hasBalcony, hasView, hasAC, hasHeating, bedSize, hasTV, hasCofeeMaker, hasHypoallergenicBedding, hasIron, hasHairDryer, ACVoltage, hasBreakfastIncluded);
            JOptionPane.showMessageDialog(null, response);
            editFrame.dispose();
        });

        editPanel.add(typeLabel);
        editPanel.add(tipoField);
        editPanel.add(towerLabel);
        editPanel.add(towerField);
        editPanel.add(floorLabel);
        editPanel.add(floorField);
        editPanel.add(idLabel);
        editPanel.add(idField);
        editPanel.add(capacityLabel);
        editPanel.add(capacityField);
        editPanel.add(sizeLabel);
        editPanel.add(sizeField);
        editPanel.add(hasKitchenLabel);
        editPanel.add(hasKitchenCheckBox);
        editPanel.add(hasBalconyLabel);
        editPanel.add(hasBalconyCheckBox);
        editPanel.add(hasViewLabel);
        editPanel.add(hasViewCheckBox);
        editPanel.add(hasACLabel);
        editPanel.add(hasACCheckBox);
        editPanel.add(hasHeatingLabel);
        editPanel.add(hasHeatinCheckBox);
        editPanel.add(bedSizeLabel);
        editPanel.add(bedSizeField);
        editPanel.add(hasTVLabel);
        editPanel.add(hasTVCheckBox);
        editPanel.add(hasCofeeLabel);
        editPanel.add(hasCofeeCheckBox);
        editPanel.add(hasHypoLabel);
        editPanel.add(hasHypoCheckBox);
        editPanel.add(hasIronLabel);
        editPanel.add(hasIronCheckBox);
        editPanel.add(hasHairLabel);
        editPanel.add(hasHairCheckBox);
        editPanel.add(ACVLabel);
        editPanel.add(ACVField);
        editPanel.add(hasBreakfastLabel);
        editPanel.add(hasBreakfastCheckBox);

        editPanel.add(confirmButton);

        editFrame.getContentPane().add(editPanel);
        editFrame.pack();
        editFrame.setLocationRelativeTo(null);
        editFrame.setVisible(true);
    }

    private void showEdit2Screen(String selectedOption, String selectedItem) {

        JFrame editFrame = new JFrame("Edit " + selectedOption);
        editFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Components for editing a service, for example:
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();
        JLabel priceLabel = new JLabel("Price:");
        JTextField priceField = new JTextField();

        // A button for confirming the edits
        JButton confirmButton = new JButton("Confirm");
        confirmButton.addActionListener(e -> {
            String name = nameField.getText();
            String response = null;

            try {
                Float price = Float.parseFloat(priceField.getText());

                // Call the appropriate method based on the selected option
                if (selectedOption.equals("Services")) {
                    response = loadInfoController.editService(selectedItem, name, price);
                } else if (selectedOption.equals("Products")) {
                    // Call your method to edit a product here
                    response = loadInfoController.editProduct(selectedItem, name, price);
                } else if (selectedOption.equals("Menu")) {
                    // Call your method to edit a menu item here
                    response = loadInfoController.editMenu(selectedItem, name, price);
                }
            } catch (NumberFormatException e1) {
                response = "Invalid Input";
            }

            JOptionPane.showMessageDialog(null, response);
            editFrame.dispose();
        });

        JPanel editPanel = new JPanel();
        editPanel.setLayout(new GridLayout(0, 2));

        // Add the components to the panel
        editPanel.add(nameLabel);
        editPanel.add(nameField);
        editPanel.add(priceLabel);
        editPanel.add(priceField);

        editPanel.add(confirmButton);

        // Add the panel to the frame
        editFrame.getContentPane().add(editPanel);
        editFrame.pack();
        editFrame.setLocationRelativeTo(null);
        editFrame.setVisible(true);
    }

    private void showCreate2Screen(String selectedOption) {

        JFrame editFrame = new JFrame("Create " + selectedOption);
        editFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Components for editing a service, for example:
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();
        JLabel priceLabel = new JLabel("Price:");
        JTextField priceField = new JTextField();

        // A button for confirming the edits
        JButton confirmButton = new JButton("Confirm");
        confirmButton.addActionListener(e -> {
            String name = nameField.getText();
            String response = null;

            try {
                Float price = Float.parseFloat(priceField.getText());

                // Call the appropriate method based on the selected option
                if (selectedOption.equals("Services")) {
                    response = loadInfoController.createService(name, price);
                } else if (selectedOption.equals("Products")) {
                    // Call your method to edit a product here
                    response = loadInfoController.createProduct(name, price);
                } else if (selectedOption.equals("Menu")) {
                    // Call your method to edit a menu item here
                    response = loadInfoController.createMenu(name, price);
                }
            } catch (NumberFormatException e1) {
                response = "Invalid Input";
            }

            JOptionPane.showMessageDialog(null, response);
            editFrame.dispose();
        });

        JPanel editPanel = new JPanel();
        editPanel.setLayout(new GridLayout(0, 2));

        // Add the components to the panel
        editPanel.add(nameLabel);
        editPanel.add(nameField);
        editPanel.add(priceLabel);
        editPanel.add(priceField);

        editPanel.add(confirmButton);

        // Add the panel to the frame
        editFrame.getContentPane().add(editPanel);
        editFrame.pack();
        editFrame.setLocationRelativeTo(null);
        editFrame.setVisible(true);
    }


    private void showCreateOptions() {
        JFrame inventoryFrame = new JFrame("Create Inventory Options");
        inventoryFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel inventoryPanel = new JPanel();
        inventoryPanel.setLayout(null);

        String[] options = {"Rooms", "Services", "Products", "Menu"};
        JComboBox<String> optionsComboBox = new JComboBox<>(options);
        optionsComboBox.setBounds(10, 10, 240, 30);

        JButton createButton = new JButton("Create");
        createButton.setBounds(170, 90, 80, 30);

        createButton.addActionListener(e -> {
            String selectedOption = (String) optionsComboBox.getSelectedItem();

            if (selectedOption.equals("Rooms")) {
                showCreateScreen(selectedOption);  // You need to implement this method
            } else if (selectedOption.equals("Services")) {
                showCreate2Screen(selectedOption); // You need to implement this method
            } else if (selectedOption.equals("Products")) {
                showCreate2Screen(selectedOption); // You need to implement this method
            } else if (selectedOption.equals("Menu")) {
                showCreate2Screen(selectedOption); // You need to implement this method
            }
        });

        inventoryPanel.add(optionsComboBox);
        inventoryPanel.add(createButton);

        inventoryFrame.getContentPane().add(inventoryPanel);
        inventoryFrame.setSize(270, 130);
        inventoryFrame.setVisible(true);
    }

    public void showAdjustRates() {
        JFrame rateFrame = new JFrame("Adjust Rates");
        rateFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel ratePanel = new JPanel();
        ratePanel.setLayout(new GridLayout(4, 2)); // 4 rows, 2 columns

        JLabel standardLabel = new JLabel("Standard Room Rate:");
        JTextField standardField = new JTextField();

        JLabel suiteLabel = new JLabel("Suite Room Rate:");
        JTextField suiteField = new JTextField();

        JLabel doubleSuiteLabel = new JLabel("Suite Double Room Rate:");
        JTextField doubleSuiteField = new JTextField();

        JButton confirmButton = new JButton("Confirm");
        confirmButton.addActionListener(e -> {
            try {
                Float standardRate = Float.parseFloat(standardField.getText());
                Float suiteRate = Float.parseFloat(suiteField.getText());
                Float doubleSuiteRate = Float.parseFloat(doubleSuiteField.getText());
                
                // Assume reservationHandler is an instance of ReservationHandler
                String response = reservationHandler.setRate(standardRate, suiteRate, doubleSuiteRate);
                JOptionPane.showMessageDialog(null, response);
                rateFrame.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.");
            }
        });

        ratePanel.add(standardLabel);
        ratePanel.add(standardField);

        ratePanel.add(suiteLabel);
        ratePanel.add(suiteField);

        ratePanel.add(doubleSuiteLabel);
        ratePanel.add(doubleSuiteField);

        ratePanel.add(confirmButton);

        rateFrame.getContentPane().add(ratePanel);
        rateFrame.pack();
        rateFrame.setLocationRelativeTo(null);
        rateFrame.setVisible(true);
    }

    private void showEditOptions() {
        JFrame inventoryFrame = new JFrame("Inventory Options");
        inventoryFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel inventoryPanel = new JPanel();
        inventoryPanel.setLayout(null);

        String[] options = {"Rooms", "Services", "Products", "Menu"};
        JComboBox<String> optionsComboBox = new JComboBox<>(options);
        optionsComboBox.setBounds(10, 10, 240, 30);

        JComboBox<String> itemComboBox = new JComboBox<>();
        itemComboBox.setBounds(10, 50, 240, 30);

        JButton editButton = new JButton("Edit");
        editButton.setBounds(170, 90, 80, 30);

        optionsComboBox.addActionListener(e -> {
            String selectedOption = (String) optionsComboBox.getSelectedItem();
            itemComboBox.removeAllItems();

            if (selectedOption.equals("Rooms")) {
                for (String roomNumber : loadInfoController.getRooms().keySet()) {
                    itemComboBox.addItem(roomNumber);
                }
            } else if (selectedOption.equals("Services")) {
                for (String service : loadInfoController.getServices().keySet()) {
                    itemComboBox.addItem(service);
                }
            } else if (selectedOption.equals("Products")) {
                for (String product : loadInfoController.getProducts().keySet()) {
                    itemComboBox.addItem(product);
                }
            } else if (selectedOption.equals("Menu")) {
                for (String menuItem : loadInfoController.getMenu().keySet()) {
                    itemComboBox.addItem(menuItem);
                }
            }
        });

        editButton.addActionListener(e -> {
            String selectedOption = (String) optionsComboBox.getSelectedItem();
            String selectedItem = (String) itemComboBox.getSelectedItem();
        
            if (selectedOption.equals("Rooms")) {
                showEditScreen(selectedItem);
            } else if (selectedOption.equals("Services")) {
                showEdit2Screen(selectedOption,selectedItem);
            }else if (selectedOption.equals("Products")) {
                showEdit2Screen(selectedOption,selectedItem);
            }else if (selectedOption.equals("Menu")) {
                showEdit2Screen(selectedOption,selectedItem);
            }
        
            // Implement other options for "Products" and "Menu" here...
        });

        inventoryPanel.add(optionsComboBox);
        inventoryPanel.add(itemComboBox);
        inventoryPanel.add(editButton);

        inventoryFrame.getContentPane().add(inventoryPanel);
        inventoryFrame.setSize(270, 130);
        inventoryFrame.setVisible(true);
    }

    private void showRestaurantView(){

        RestaurantGraph restaurantGraph = new RestaurantGraph(loadInfoController);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == createButton) {
            showCreateOptions();
        } else if(e.getSource() == editButton) {
            showEditOptions();
        } else if(e.getSource() == checkInventoryButton) {
            showInventoryOptions();
        } else if(e.getSource() == adjustRatesButton) {
            showAdjustRates();
        } else if(e.getSource() == showRestaurant) {
            showRestaurantView();
        }
    }

    }
